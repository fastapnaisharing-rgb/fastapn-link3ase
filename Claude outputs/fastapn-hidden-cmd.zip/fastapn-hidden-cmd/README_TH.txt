FastAPN - ไม่ให้หน้าต่าง cmd เด้ง (SP Handler v7)

ไฟล์ที่แก้ (วางทับใน C:\apps\fastapn-backend\src\routes ด้วย deploy-backend.ps1):
  src\routes\fileStorage.js        Outlook handler: Registry เปิดผ่าน wscript //B + แนบ fastapn-run-hidden.vbs ใน zip
  src\routes\spHandlerAssets.js    SP Handler v7 (ซ่อนหน้าต่าง + ปรับ Registry อัตโนมัติ)
  src\routes\System.js             exec/execSync ใส่ windowsHide: true
  src\routes\ocr_routes.js         spawn Python ใส่ windowsHide: true

ฝั่งผู้ใช้:
  - SharePoint Handler: หลัง deploy เครื่องที่เป็น v6 จะอัปเดตเป็น v7 และปรับ Registry เองในการใช้งานครั้งถัดไป
  - Outlook Handler (fastapn://): เครื่องที่มี D:\apps\fastapn-outlook.ps1 จะถูกปรับ Registry ให้เองเมื่อ SP Handler v7 ทำงานครั้งแรก
    (หรือโหลด zip Outlook ใหม่แล้วรัน setup-fastapn-outlook.bat)
  - ติดตั้งใหม่: setup-fastapn-sp.bat / setup-fastapn-outlook.bat ยังมีหน้าต่างให้เห็นตอนติดตั้ง (ทำครั้งเดียว)

_bak\ = ไฟล์เดิมก่อนแก้ (กู้คืนโดยวางกลับแล้ว Restart-Service fastapn-backend)
