// vatMailPivot.js -- MARKER_VATMAILEXPORT_REAL_PIVOT_V1
// ฝัง PivotTable "ตัวจริง" ของ Excel ลงในไฟล์ .xlsx (ExcelJS สร้าง Pivot เองไม่ได้)
// ใส่ Pivot Cache (พร้อม Records) + Pivot Table + refreshOnLoad -> เปิดไฟล์แล้ว Excel คำนวณ/วาด Pivot ให้เอง
import JSZip from "jszip";

const esc = (s) => String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const isoDate = (d) => d.toISOString().slice(0, 19);
const kindOf = (v) => (v == null || v === "" ? "m" : v instanceof Date ? "d" : typeof v === "number" ? "n" : "s");

/**
 * header: string[]          -- ชื่อคอลัมน์ของชีทข้อมูล (A1..)
 * rows:   any[][]           -- ค่าแต่ละแถว (Date | number | string | null) ต้องตรงกับที่เขียนลงชีทจริง
 * opts: { dataSheet, hostSheetFile, rowFields:number[], pageField:number, dataFields:[{idx,name}], pivotRef:'A10', cacheId }
 */
export async function injectPivot(buffer, { header, rows, dataSheet, hostSheetFile = "sheet1.xml", rowFields, pageField, dataFields, pivotTop = 10, cacheId = 1 }) {
  const nCols = header.length;
  const colLetter = (n) => { let s = ""; n += 1; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; };

  // ── วิเคราะห์ชนิดข้อมูลต่อคอลัมน์ ──
  const cols = header.map((name, c) => {
    const vals = rows.map((r) => r[c]);
    const kinds = new Set(vals.map(kindOf));
    const hasBlank = kinds.has("m");
    kinds.delete("m");
    let type = "s";
    if (kinds.size === 1 && kinds.has("n")) type = "n";
    else if (kinds.size === 1 && kinds.has("d")) type = "d";
    const enumerate = rowFields.includes(c) || c === pageField;
    let items = null; const idxOf = new Map();
    if (enumerate) {
      const seen = new Map();
      vals.forEach((v) => { if (v == null || v === "") return; const key = type === "d" ? isoDate(v) : String(v); if (!seen.has(key)) seen.set(key, v); });
      items = [...seen.keys()].sort((a, b) => (type === "n" ? Number(a) - Number(b) : a.localeCompare(b, "th")));
      items.forEach((k, i) => idxOf.set(k, i));
      if (hasBlank) { idxOf.set("\u0000blank", items.length); }
    }
    let minV; let maxV;
    if (type === "n") { const ns = vals.filter((v) => typeof v === "number"); minV = Math.min(...ns); maxV = Math.max(...ns); }
    if (type === "d") { const ds = vals.filter((v) => v instanceof Date).map((v) => v.getTime()); minV = new Date(Math.min(...ds)); maxV = new Date(Math.max(...ds)); }
    return { name, type, hasBlank, items, idxOf, minV, maxV };
  });

  // ── pivotCacheDefinition ──
  const cacheFields = cols.map((c) => {
    let si;
    if (c.type === "n") si = `<sharedItems containsSemiMixedTypes="0" containsString="0" containsNumber="1"${c.hasBlank ? "" : ""} minValue="${c.minV}" maxValue="${c.maxV}"/>`;
    else if (c.type === "d") si = `<sharedItems${c.hasBlank ? "" : ' containsSemiMixedTypes="0"'} containsNonDate="0" containsDate="1" containsString="0"${c.hasBlank ? ' containsBlank="1"' : ""} minDate="${isoDate(c.minV)}" maxDate="${isoDate(c.maxV)}"${c.items ? ` count="${c.items.length + (c.hasBlank ? 1 : 0)}"` : ""}>${c.items ? c.items.map((k) => `<d v="${k}"/>`).join("") + (c.hasBlank ? "<m/>" : "") : ""}</sharedItems>`;
    else if (c.items) si = `<sharedItems${c.hasBlank ? ' containsBlank="1"' : ""} count="${c.items.length + (c.hasBlank ? 1 : 0)}">${c.items.map((k) => `<s v="${esc(k)}"/>`).join("")}${c.hasBlank ? "<m/>" : ""}</sharedItems>`;
    else si = `<sharedItems${c.hasBlank ? ' containsBlank="1"' : ""}/>`;
    const nf = c.type === "d" ? ' numFmtId="15"' : c.type === "n" ? ' numFmtId="4"' : ' numFmtId="0"';
    return `<cacheField name="${esc(c.name)}"${nf}>${si}</cacheField>`;
  }).join("");
  const lastRow = rows.length + 1;
  const cacheDef = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<pivotCacheDefinition xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:id="rId1" refreshOnLoad="1" refreshedBy="Link3ase" refreshedDate="${(Date.now() / 86400000 + 25569).toFixed(6)}" createdVersion="6" refreshedVersion="6" minRefreshableVersion="3" recordCount="${rows.length}"><cacheSource type="worksheet"><worksheetSource ref="A1:${colLetter(nCols - 1)}${lastRow}" sheet="${esc(dataSheet)}"/></cacheSource><cacheFields count="${nCols}">${cacheFields}</cacheFields></pivotCacheDefinition>`;

  // ── pivotCacheRecords ──
  const recs = rows.map((r) => `<r>${cols.map((c, i) => {
    const v = r[i]; const blank = v == null || v === "";
    if (c.items) { const k = blank ? "\u0000blank" : (c.type === "d" ? isoDate(v) : String(v)); return `<x v="${c.idxOf.get(k)}"/>`; }
    if (blank) return "<m/>";
    if (c.type === "n") return `<n v="${v}"/>`;
    if (c.type === "d") return `<d v="${isoDate(v)}"/>`;
    return `<s v="${esc(v)}"/>`;
  }).join("")}</r>`).join("");
  const cacheRec = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<pivotCacheRecords xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" count="${rows.length}">${recs}</pivotCacheRecords>`;

  // ── pivotTableDefinition ──
  const dataIdx = dataFields.map((d) => d.idx);
  const pivotFields = cols.map((c, i) => {
    const itemsXml = (withDefault) => c.items ? `<items count="${c.items.length + (c.hasBlank ? 1 : 0) + (withDefault ? 1 : 0)}">${c.items.map((_, k) => `<item x="${k}"/>`).join("")}${c.hasBlank ? `<item x="${c.items.length}"/>` : ""}${withDefault ? '<item t="default"/>' : ""}</items>` : "";
    const nf = c.type === "d" ? ' numFmtId="15"' : "";
    const rowPos = rowFields.indexOf(i);
    if (rowPos >= 0) {
      const outer = rowPos === 0; // Subtotal เฉพาะ Related Persons (ชั้นนอกสุด) เหมือนไฟล์ตัวอย่าง
      return `<pivotField axis="axisRow" compact="0"${nf} outline="0" showAll="0"${outer ? "" : ' defaultSubtotal="0"'}>${itemsXml(outer)}</pivotField>`;
    }
    if (i === pageField) return `<pivotField axis="axisPage" compact="0" outline="0" multipleItemSelectionAllowed="1" showAll="0">${itemsXml(true)}</pivotField>`;
    if (dataIdx.includes(i)) return `<pivotField dataField="1" compact="0" outline="0" showAll="0"/>`;
    return `<pivotField compact="0"${nf} outline="0" showAll="0"/>`;
  }).join("");
  const nRow = rowFields.length;
  const ptDef = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<pivotTableDefinition xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" name="ICP_Following" cacheId="${cacheId}" applyNumberFormats="0" applyBorderFormats="0" applyFontFormats="0" applyPatternFormats="0" applyAlignmentFormats="0" applyWidthHeightFormats="1" dataCaption="Values" updatedVersion="6" minRefreshableVersion="3" useAutoFormatting="1" itemPrintTitles="1" createdVersion="6" indent="0" compact="0" compactData="0" multipleFieldFilters="0"><location ref="A${pivotTop}:${colLetter(nRow + dataFields.length - 1)}${pivotTop + 1}" firstHeaderRow="0" firstDataRow="1" firstDataCol="${nRow}" rowPageCount="1" colPageCount="1"/><pivotFields count="${nCols}">${pivotFields}</pivotFields><rowFields count="${nRow}">${rowFields.map((f) => `<field x="${f}"/>`).join("")}</rowFields><colFields count="1"><field x="-2"/></colFields><pageFields count="1"><pageField fld="${pageField}" hier="-1"/></pageFields><dataFields count="${dataFields.length}">${dataFields.map((d) => `<dataField name="${esc(d.name)}" fld="${d.idx}" baseField="0" baseItem="0" numFmtId="4"/>`).join("")}</dataFields><pivotTableStyleInfo name="PivotStyleLight16" showRowHeaders="1" showColHeaders="1" showRowStripes="0" showColStripes="0" showLastColumn="1"/></pivotTableDefinition>`;

  // ── ประกอบเข้า zip ──
  const zip = await JSZip.loadAsync(buffer);
  zip.file("xl/pivotCache/pivotCacheDefinition1.xml", cacheDef);
  zip.file("xl/pivotCache/pivotCacheRecords1.xml", cacheRec);
  zip.file("xl/pivotCache/_rels/pivotCacheDefinition1.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/pivotCacheRecords" Target="pivotCacheRecords1.xml"/></Relationships>`);
  zip.file("xl/pivotTables/pivotTable1.xml", ptDef);
  zip.file("xl/pivotTables/_rels/pivotTable1.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/pivotCacheDefinition" Target="../pivotCache/pivotCacheDefinition1.xml"/></Relationships>`);

  const relPath = `xl/worksheets/_rels/${hostSheetFile}.rels`;
  const pivRel = `<Relationship Id="rIdPivot1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/pivotTable" Target="../pivotTables/pivotTable1.xml"/>`;
  const existing = zip.file(relPath);
  if (existing) { const t = await existing.async("string"); zip.file(relPath, t.replace("</Relationships>", `${pivRel}</Relationships>`)); }
  else zip.file(relPath, `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${pivRel}</Relationships>`);

  let wbXml = await zip.file("xl/workbook.xml").async("string");
  const pc = `<pivotCaches><pivotCache cacheId="${cacheId}" r:id="rIdPivotCache1"/></pivotCaches>`;
  if (!/xmlns:r=/.test(wbXml)) wbXml = wbXml.replace("<workbook ", '<workbook xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" ');
  if (/<extLst>/.test(wbXml)) wbXml = wbXml.replace("<extLst>", `${pc}<extLst>`); else wbXml = wbXml.replace("</workbook>", `${pc}</workbook>`);
  zip.file("xl/workbook.xml", wbXml);

  let wbRels = await zip.file("xl/_rels/workbook.xml.rels").async("string");
  wbRels = wbRels.replace("</Relationships>", `<Relationship Id="rIdPivotCache1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/pivotCacheDefinition" Target="pivotCache/pivotCacheDefinition1.xml"/></Relationships>`);
  zip.file("xl/_rels/workbook.xml.rels", wbRels);

  let ct = await zip.file("[Content_Types].xml").async("string");
  ct = ct.replace("</Types>", `<Override PartName="/xl/pivotCache/pivotCacheDefinition1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.pivotCacheDefinition+xml"/><Override PartName="/xl/pivotCache/pivotCacheRecords1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.pivotCacheRecords+xml"/><Override PartName="/xl/pivotTables/pivotTable1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.pivotTable+xml"/></Types>`);
  zip.file("[Content_Types].xml", ct);

  return zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
}
