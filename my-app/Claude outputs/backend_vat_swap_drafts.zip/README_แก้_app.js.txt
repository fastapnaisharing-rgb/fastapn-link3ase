Backend ที่ต้องแก้สำหรับ Draft ของ VAT Swap Finder (โฟลเดอร์ fastapn-backend)

1) ไฟล์ใหม่ (วางตามโครงสร้างในซิปนี้)
   src\routes\vatSwapDrafts.js

2) แก้ src\app.js เพิ่ม 2 บรรทัด (อย่างใดอย่างหนึ่ง)
   ก. รัน python patch_vat_swap_drafts_v1.py ในโฟลเดอร์ fastapn-backend (สำรอง app.js ให้เอง), หรือ
   ข. เพิ่มเอง: ใต้บรรทัด import router อื่น ๆ
        import vatSwapDraftsRouter from "./routes/vatSwapDrafts.js";
      ใต้บรรทัด app.use("/api/...", ...) อื่น ๆ
        app.use("/api/vat-swap-drafts", vatSwapDraftsRouter);

3) ตรวจ limit ของ express.json ใน app.js -- ควรเป็น express.json({ limit: "50mb" }) ขึ้นไป

4) Restart-Service fastapn-backend  (ตาราง vat_swap_drafts / vat_swap_draft_rows สร้างเองตอนเริ่ม และล้างรายการหมดอายุเองทุก 6 ชั่วโมง)
