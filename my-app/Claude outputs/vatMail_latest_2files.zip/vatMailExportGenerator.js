// vatMailExportGenerator.js -- MARKER_VATMAILEXPORT_GENERATOR_V1
// ── Pure Function (ไม่แตะ DB) สร้าง Excel / เนื้อหาเมล สำหรับ Config Email ──
import ExcelJS from "exceljs";
import { injectPivot } from "./vatMailPivot.js";

const MONTHS_EN = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

export const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
export const fmtMoney = (v) => num(v).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// "2026-09" -> เลื่อนถอยหลัง n เดือน -> { y, m }
export function shiftMonth(period, back) {
  const m = String(period || "").match(/^(\d{4})-(\d{2})/);
  const now = new Date();
  let y = m ? Number(m[1]) : now.getFullYear();
  let mo = m ? Number(m[2]) : now.getMonth() + 1;
  let idx = y * 12 + (mo - 1) - back;
  return { y: Math.floor(idx / 12), m: (idx % 12) + 1 };
}
export const monthLabel = (period, agingBack) => { const { y, m } = shiftMonth(period, agingBack); return `${MONTHS_EN[m - 1]} ${y}`; };

// Asset = Branch ขึ้นต้นด้วย T/F, Expense = A หรือไม่มีตัวอักษรนำหน้า
export const taxGroupOf = (branch) => (/^[TF]/i.test(String(branch || "").trim()) ? "Asset" : "Expense");
const cleanBranch = (b) => String(b || "").trim().replace(/^[ATF]/i, "");

// ── จับคู่ Related Person (วิธีเดียวกับ Group Range: ตัด A/T/F -> อ่าน N ตำแหน่ง -> เทียบ Range -> Range แคบสุดชนะ) ──
export function matchRelatedPerson(row, rules) {
  if (!Array.isArray(rules) || rules.length === 0) return "";
  const key0 = cleanBranch(row.branch);
  const group = taxGroupOf(row.branch).toUpperCase();
  let best = null; let bestSpan = Infinity;
  for (const r of rules) {
    const t = String(r.person_type || "ALL").toUpperCase();
    if (t !== "ALL" && t !== group) continue;
    const len = r.prefix_length;
    const key = len ? key0.slice(0, Number(len)) : key0;
    if (key >= String(r.range_start) && key <= String(r.range_end)) {
      const span = (Number(r.range_end) || 0) - (Number(r.range_start) || 0);
      if (span < bestSpan) { bestSpan = span; best = r.related_person; }
    }
  }
  return best || "";
}

// ── แทนตัวแปรใน Subject/Body ──
export function applyVars(text, vars) {
  return String(text || "").replace(/\{([^{}]+)\}/g, (all, k) => (Object.prototype.hasOwnProperty.call(vars, k.trim()) ? String(vars[k.trim()]) : all));
}

// ── บรรทัดสรุปรายเดือน (เรียง Aging มาก -> น้อย = เดือนเก่า -> ใหม่) ──
export function buildAgingLines(rows, agingList, period) {
  const sums = {};
  rows.forEach((r) => { const a = Number(r.aging_months); sums[a] = (sums[a] || 0) + num(r.exp_vat); });
  const list = (agingList && agingList.length ? agingList : [6, 5, 4, 3, 2, 1, 0]).map(Number).filter((a) => a >= 0 && a <= 6).sort((a, b) => b - a);
  return list.map((a) => ({
    aging: a,
    month: monthLabel(period, a),
    total: sums[a] || 0,
    color: a >= 5 ? "red" : "green", // Aging 5-6 = แดง (กลุ่ม 6-5), 0-4 = เขียว
    text: `รายการคงค้างที่ตัดชำระเงินในเดือน ${monthLabel(period, a)} จำนวนภาษียังไม่ได้สิทธิ์ : ${fmtMoney(sums[a] || 0)} บาท`,
  }));
}

const HEAD_FILL = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1A3A5C" } };
const SUB_FILL = { type: "pattern", pattern: "solid", fgColor: { argb: "FFE3EDF7" } };
const GRAND_FILL = { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFF2CC" } };
const MONEY = "#,##0.00";
const thin = { style: "thin", color: { argb: "FFBBBBBB" } };

function styleHeader(row) {
  row.eachCell((c) => { c.fill = HEAD_FILL; c.font = { bold: true, color: { argb: "FFFFFFFF" } }; c.alignment = { vertical: "middle", horizontal: "center", wrapText: true }; c.border = { top: thin, bottom: thin, left: thin, right: thin }; });
}
const dateOnly = (v) => { if (!v) return null; const d = new Date(v); return Number.isNaN(d.getTime()) ? null : new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())); };

function autoWidth(ws, min = 8, max = 48) {
  ws.columns.forEach((col) => {
    let w = min;
    col.eachCell({ includeEmpty: false }, (c) => { const v = c.value == null ? "" : (c.value instanceof Date ? "dd-mmm-yy" : String(c.value)); w = Math.max(w, Math.min(max, v.length + 2)); });
    col.width = w;
  });
}

const SAMPLE_HEAD_FILL = { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFFFCC" } };
function styleHeaderSample(row) { // ตามไฟล์ตัวอย่าง: ตัวอักษรน้ำเงินเข้ม พื้นเหลืองอ่อน กึ่งกลาง
  row.eachCell((c) => { c.fill = SAMPLE_HEAD_FILL; c.font = { name: "Tahoma", color: { argb: "FF002060" } }; c.alignment = { vertical: "middle", horizontal: "center" }; });
}

// ── Workbook ส่งถึง BU: ชีท Pivot (PivotTable จริง) + Raw + Aging Summary ──
export async function buildBuWorkbook({ rows, period, buLabel, generatedBy }) {
  const wb = new ExcelJS.Workbook();
  wb.creator = generatedBy || "Link3ase";

  // ---------- Pivot (ชีทแรก = sheet1.xml) : หัวรายงาน + พื้นที่ให้ PivotTable วาง ----------
  const pv = wb.addWorksheet("Incompleted_Pivot", { views: [{ state: "frozen", ySplit: 10, zoomScale: 90, showGridLines: false }] });
  pv.addRow([`รายการใบกำกับภาษีที่ยังไม่ได้รับ — ${buLabel}`]).font = { bold: true, size: 14, color: { argb: "FF1A3A5C" } };
  pv.addRow([`Period: ${period || "-"}   |   จำนวนรายการ: ${rows.length.toLocaleString()}   |   สร้างเมื่อ: ${new Date().toLocaleString("en-GB")}`]).font = { color: { argb: "FF666666" } };
  pv.addRow(["* Pivot Table จริง -- ถ้าตัวเลขไม่ขึ้น กด Data > Refresh All  |  เลือก Aging / Asset-Expense ได้ที่ Slicer ด้านบน"]).font = { italic: true, size: 9, color: { argb: "FF999999" } };
  [20.6, 90.6, 20.6, 10.6, 23.6, 12.6, 31, 16, 14.25].forEach((w, i) => { pv.getColumn(i + 1).width = w; }); // ความกว้างตามไฟล์ตัวอย่าง

  // ---------- Raw ----------
  const raw = wb.addWorksheet("ICP_Report_BU");
  const rawHead = ["ว.ด.ป.", "เลขที่", "Site", "Pay Group", "Branch", "ประเภทภาษี", "ใบแจ้งหนี้", "Supplier Code", "ชื่อผู้ค้า", "Business", "ชำระเงิน", "เช็ค", "เลขที่เช็ค", "Receive Doc.", "มูลค่าสินค้า", "เงินภาษี", "BU", "Aging", "Period", "Tax Group", "Related Persons", "AP Batch Name"];
  const dash = (v) => (v == null || String(v).trim() === "" ? "-" : String(v));
  const rawData = rows.map((r) => [
    r.doc_date == null ? null : String(r.doc_date), r.doc_no == null ? null : String(r.doc_no), r.site || null, r.pay_group || null, r.branch || null, r.tax_type || null,
    dash(r.invoice_ref), dash(r.supplier_code), dash(r.vendor_name), r.bus_type || null, dateOnly(r.payment_date), dateOnly(r.check_date), dash(r.check_no), r.receive_doc_no || null,
    num(r.exp_amount), num(r.exp_vat), dash(r.bu), `aging ${r.aging_months} month`, r.period || null, r._taxGroup, r._person || "ไม่ระบุ", r.ap_batch_name || null,
  ]);
  styleHeaderSample(raw.addRow(rawHead));
  rawData.forEach((r) => raw.addRow(r));
  [11, 12].forEach((c) => { raw.getColumn(c).numFmt = "dd-mmm-yy"; });
  [15, 16].forEach((c) => { raw.getColumn(c).numFmt = MONEY; });
  raw.views = [{ state: "frozen", ySplit: 1 }];
  raw.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: rawHead.length } };
  autoWidth(raw);

  // ---------- Aging Summary (เหมือนไฟล์ตัวอย่าง: ตารางเรียบ ใช้สูตร SUMIF) ----------
  const ag = wb.addWorksheet("Aging Summary");
  ag.addRow(["Aging", "Period", "Summary Vat"]);
  const agSum = {};
  rows.forEach((r) => { const a = Number(r.aging_months); agSum[a] = (agSum[a] || 0) + num(r.exp_vat); });
  [6, 5, 4, 3, 2, 1, 0].forEach((a, i) => {
    const r = i + 2;
    const row = ag.addRow([`aging ${a} month`, monthLabel(period, a), { formula: `SUMIF(ICP_Report_BU!$R:$R,$A${r},ICP_Report_BU!$P:$P)`, result: agSum[a] || 0 }]);
    row.getCell(3).numFmt = MONEY;
  });
  [18, 18, 18].forEach((w, i) => { ag.getColumn(i + 1).width = w; });

  wb.views = [{ activeTab: 0 }];
  let buf = Buffer.from(await wb.xlsx.writeBuffer());
  let pivotOk = true;
  try {
    // Row: Related Persons > ชื่อผู้ค้า > Supplier Code > BU > เลขที่เช็ค > ชำระเงิน > ใบแจ้งหนี้ | Filter: Tax Group | Values: Sum มูลค่าสินค้า, เงินภาษี
    buf = await injectPivot(buf, {
      header: rawHead, rows: rawData, dataSheet: "ICP_Report_BU", hostSheetFile: "sheet1.xml",
      rowFields: [20, 8, 7, 16, 12, 10, 6],
      slicers: [
        { field: 17, caption: "Aging", from: [3, 3], to: [7, 7], columnCount: 4, reverse: true },
        { field: 19, caption: "Tax Group", from: [7, 3], to: [9, 7], columnCount: 2 },
      ],
      dataFields: [{ idx: 14, name: "Sum of มูลค่าสินค้า" }, { idx: 15, name: "Sum of เงินภาษี" }], pivotTop: 10,
    });
  } catch (e) { pivotOk = false; console.error("injectPivot failed:", e); }
  const grandA = rows.reduce((t, r) => t + num(r.exp_amount), 0);
  const grandV = rows.reduce((t, r) => t + num(r.exp_vat), 0);
  return { buffer: buf, grandAmount: grandA, grandVat: grandV, pivotOk };
}

// ── Workbook ส่งถึง Supplier: ชีทเดียว List เรียงตาม BU ──
export async function buildSupplierWorkbook({ rows, buInfoByBu, branchInfoByCode, supplierLabel }) {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet("Outstanding");
  ws.addRow([`รายการใบกำกับภาษีที่ยังไม่ได้รับ — ${supplierLabel}`]).font = { bold: true, size: 13, color: { argb: "FF1A3A5C" } };
  ws.addRow([]);
  const HEAD = ["BU", "ชื่อ BU", "Tax ID", "Branch", "เลขที่เช็ค", "ชำระเงิน", "ใบแจ้งหนี้", "มูลค่าสินค้า", "เงินภาษี"];
  styleHeader(ws.addRow(HEAD));
  const sorted = [...rows].sort((a, b) => String(a.bu || "").localeCompare(String(b.bu || "")) || (dateOnly(a.payment_date) || 0) - (dateOnly(b.payment_date) || 0) || String(a.invoice_ref || "").localeCompare(String(b.invoice_ref || "")));
  let sA = 0; let sV = 0;
  sorted.forEach((r) => {
    const bi = buInfoByBu[r.bu] || {};
    const br = branchInfoByCode[cleanBranch(r.branch)] || branchInfoByCode[String(r.branch || "").trim()] || {};
    const row = ws.addRow([r.bu, bi.name || "", bi.taxId || "", br.branch || bi.branch || "", r.check_no, dateOnly(r.payment_date), r.invoice_ref, num(r.exp_amount), num(r.exp_vat)]);
    row.getCell(6).numFmt = "dd-mmm-yy"; row.getCell(8).numFmt = MONEY; row.getCell(9).numFmt = MONEY;
    sA += num(r.exp_amount); sV += num(r.exp_vat);
  });
  const t = ws.addRow(["Total", null, null, null, null, null, null, sA, sV]);
  t.eachCell({ includeEmpty: true }, (c) => { c.font = { bold: true }; c.fill = GRAND_FILL; });
  t.getCell(8).numFmt = MONEY; t.getCell(9).numFmt = MONEY;
  [10, 40, 18, 10, 18, 12, 26, 16, 14].forEach((w, i) => { ws.getColumn(i + 1).width = w; });
  ws.views = [{ state: "frozen", ySplit: 3 }];
  const buf = await wb.xlsx.writeBuffer();
  return { buffer: Buffer.from(buf), totalAmount: sA, totalVat: sV };
}
