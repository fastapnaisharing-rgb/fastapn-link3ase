import express from "express";
import { WebSocketServer } from "ws";
import cors from "cors";
import dotenv from "dotenv";
import os from "os";
import { execSync } from "child_process"; // MARKER_SYNC_GETCURRENTCPU_APP_V1 -- exec() ไม่ใช้แล้ว getCurrentCpu() ย้ายไป System.js

import { verifyAuthLocal } from "./middleware/authLocal.js";
import authRouter from "./routes/auth.js";
import { attachAppRole } from "./middleware/attachRole.js";
import { checkPermission } from "./middleware/checkPermission.js"; // MARKER_APP_REPLACE_BU_PERMISSION_FIX_V1
import { createTableRouter } from "./routes/genericTable.js";
import { pool, getUsernameByEmail } from "./db.js";
import apPeriodRouter, { checkAutoCloseRequest, checkAndSyncPeriodStatus } from "./routes/apPeriod.js";
import vatPeriodRouter from "./routes/vatPeriodRoute.js";
import { purgeExpiredTaxClosePeriods } from "./routes/taxClosePeriod.js"; // MARKER_TAXCLOSE_LIFECYCLE_V1
import iePeriodRouter, { checkAutoCloseIERequest, checkAndSyncIEPeriodStatus } from "./routes/iePeriod.js";
import systemRouter, { takeRamSnapshot, takeCpuSnapshot, autoCleanJunk, getCurrentCpu } from "./routes/system.js"; // MARKER_SYNC_GETCURRENTCPU_APP_V1
import fileStorageRouter, { checkAndCleanupFileStorage } from "./routes/fileStorage.js";
import vatExportRouter from "./routes/vatExport.js"; // MARKER_APP_VAT_EXPORT_ROUTER_V1 -- Export Popvat/Simple/ADI จาก Draft เป็นไฟล์ Excel
import ieExportRouter from "./routes/ieExport.js"; // MARKER_APP_IE_EXPORT_ROUTER_V1 -- Export Simple ของ IE จาก ie_simplevatdraft เป็นไฟล์ Excel
// MARKER_MOUNT_FAVORITE_ROUTER_V1
import favoriteRouter from "./routes/favorite.js";
import itemMasterSearchRouter from "./routes/itemMasterSearch.js"; // MARKER_APP_MOUNT_ITEM_MASTER_SEARCH_V1
import supplierSearchRouter from "./routes/supplierSearch.js"; // MARKER_APP_MOUNT_SUPPLIER_SEARCH_V1
// MARKER_IECODE_USAGE_TOUCH_ROUTER_V1
import ieCodeUsageRouter from "./routes/ieCodeUsage.js";
// MARKER_BATCH_COMMENTS_SYSTEM_V1
import fs from "fs";
import path from "path";
import batchCommentsRouter, { CHAT_STORAGE_ROOT } from "./routes/batchComments.js";
// MARKER_APP_REGISTER_LEGACY_ROUTES_V1
import legacyImportRouter from "./routes/legacyImport.js";
import invoiceHistoryRouter from "./routes/invoiceHistory.js";
// MARKER_APP_REGISTER_INVOICE_FLOWS_V1
import invoiceFlowsRouter from "./routes/invoiceFlows.js";
import ocrRoutes from "./routes/ocr_routes.js";
import excelReportRouter from "./routes/excelReport.js";
import docenterOcrRouter from "./routes/docenter_ocr_route.js";
import batchControlRouter from "./routes/batchControl.js"; // MARKER_APP_BATCH_CONTROL_ROUTER
import vatReconcileRouter from "./routes/vatReconcile.js"; // MARKER_APP_VAT_RECONCILE_ROUTER_V1
import apReconcileRouter from "./routes/apReconcile.js"; // MARKER_APP_MOUNT_AP_RECONCILE_ROUTER_V1
// MARKER_MOUNT_SUPPORT_ROUTER_V1
// MARKER_MOUNT_SUPPORT_RECYCLE_CRON_V1
// MARKER_APP_SUPPORT_REMINDER_CRON_V1
// MARKER_APP_SUPPORT_AUTO_AGREE_CRON_V1
// MARKER_APP_SUPPORT_ACCEPT_EXPIRY_CRON_V1
// MARKER_APP_SUPPORT_TESTING_RECALL_CRON_V1
// MARKER_APP_SUPPORT_RESTORE_NOTIF_CRON_V1
import supportRouter, { checkAndCleanupSupportThreads, checkSupportThreadReminders, checkAutoAgreeThreads, checkAndCleanupExpiredAcceptNotifications, checkTestingRecall, checkAndRestoreNewThreadNotifications } from "./routes/support.js";
import vatMailExportRouter from "./routes/vatMailExport.js"; // MARKER_APP_IMPORT_VAT_MAIL_EXPORT_V1
// MARKER_APP_DATAINTEGRITY_REMOVED_V1 -- ถอด Cron แจ้งเตือน data-integrity ออก (2026-09-28)
// เหตุผล: กด "อ่านแล้ว" ไม่เคยหายจริง (Bug filter) + Insert ซ้ำทุก 24 ชม.ไม่มี Dedup + Link ไปยัง Batch
// ไม่ได้จริง (batch_id ว่างเสมอเพราะ Query กรองเฉพาะใบที่ยังไม่เข้า Batch) -- เปลี่ยนไปบล็อกตั้งแต่จุด
// Submit/Save เข้า bucket_list ฝั่ง Frontend แทน (MARKER_BUCKETLIST_BRANCH_REQUIRED_*_V1 ใน APController.js)
// ไฟล์ ./routes/dataIntegrityCheck.js ยังอยู่ในระบบไฟล์ แต่ไม่มีจุดไหน import ใช้งานแล้ว

dotenv.config();

const app = express();

const allowedOrigins = (process.env.ALLOWED_ORIGIN || "")
  .split(",")
  .map(o => o.trim())
  .filter(Boolean);

app.use(cors({
  origin: function (origin, callback) {
    if (!origin) return callback(null, true);
    if (allowedOrigins.includes(origin)) return callback(null, true);
    console.warn("CORS blocked origin:", origin, "| allowed:", allowedOrigins);
    return callback(new Error("Not allowed by CORS: " + origin));
  }
}));
// MARKER_EXPRESS_JSON_LIMIT_25MB_V1
app.use(express.json({ limit: '150mb' })); // MARKER_EXPRESS_JSON_LIMIT_150MB_V1 -- ขยายจาก 25MB (รองรับ PDF/รูปขนาดใหญ่ Base64 พองขึ้น ~33%) // ???????? Default 100KB -> 25MB (?????????? Excel ??????? Base64)

// MARKER_APP_MENU_ENTER_ACTIVITY_V1 -- Activity เก็บเฉพาะ Action สำคัญ: เข้าระบบ (LOGIN เดิม) / เข้าเมนู (MENU_ENTER เมื่อ Heartbeat เปลี่ยนเมนู) / ออกระบบ (LOGOUT จาก WS Presence) -- ไม่เก็บทุก API
const lastMenuByUser = new Map();
const MENU_MIN_STAY_SEC = Number(process.env.MENU_MIN_STAY_SEC) || 10; // MARKER_APP_MENU_ENTER_MIN_STAY_V2 -- นับเข้าเมนูทันที แต่ถ้าอยู่ไม่เกิน 10 วิ แล้วออก = ลบรายการนั้นทิ้ง (ไม่นับ)
function logActivity(username, action, moduleName, at) { // คืน Promise<id> (null ถ้าไม่สำเร็จ)
  if (!username) return Promise.resolve(null);
  return pool.query("INSERT INTO activity_log (username, user_email, action, module, created_at) VALUES ($1, NULL, $2, $3, COALESCE($4::timestamptz, NOW())) RETURNING id", [username, action, moduleName ? String(moduleName).slice(0, 60) : null, at ? new Date(at).toISOString() : null])
    .then((r) => r.rows[0]?.id ?? null)
    .catch(async (e) => {
      if (e.code === "42703") { // ไม่มี Column id -> บันทึกแบบไม่คืน id (ไม่รองรับการลบรายการคลิกผ่าน)
        try { await pool.query("INSERT INTO activity_log (username, user_email, action, module, created_at) VALUES ($1, NULL, $2, $3, COALESCE($4::timestamptz, NOW()))", [username, action, moduleName ? String(moduleName).slice(0, 60) : null, at ? new Date(at).toISOString() : null]); } catch (e2) { console.error("[activity] log error:", e2.message); }
        return null;
      }
      console.error("[activity] log error:", e.message); return null;
    });
}
// MARKER_APP_DELETE_ACTIVITY_V1 -- Delete เป็น Action สำคัญ: บันทึกทุกการลบที่สำเร็จ (DELETE) ต่อ User (ข้ามงานเก็บกวาด Session/Notification/Log)
const DELETE_ACTIVITY_SKIP = [/menu_active_sessions/, /ap_active_sessions/, /ie_active_sessions/, /activity_log/, /notifications/, /recycle_bin/, /\/vat-reconcile\/dashboard\/report-files/];
const deleteActivityUserCache = new Map();
app.use((req, res, next) => {
  if (req.method !== "DELETE") return next();
  res.on("finish", () => {
    (async () => {
      try {
        if (res.statusCode >= 400 || !req.user?.email) return;
        const p = String(req.originalUrl || "").split("?")[0];
        if (!p.startsWith("/api/") || DELETE_ACTIVITY_SKIP.some((r) => r.test(p))) return;
        let username = req.user.username || deleteActivityUserCache.get(req.user.email);
        if (!username) { username = await getUsernameByEmail(req.user.email); if (username) deleteActivityUserCache.set(req.user.email, username); }
        if (!username) return;
        logActivity(username, ("DELETE " + p.replace(/\/\d+(?=\/|$)/g, "/:id")).slice(0, 200), (p.split("/")[2] || "").slice(0, 60));
      } catch (e) { console.error("[activity] delete log error:", e.message); }
    })();
  });
  next();
});
app.use("/api/menu_active_sessions", (req, res, next) => {
  if (!["POST", "PUT", "PATCH"].includes(req.method)) return next();
  res.on("finish", () => {
    try {
      if (res.statusCode >= 400) return;
      const b = Array.isArray(req.body) ? req.body[0] : req.body;
      const user = b && (b.user_name || b.session_id);
      const menu = b && b.menu_id;
      if (!user || !menu) return;
      const cur = lastMenuByUser.get(user);
      const now = Date.now();
      if (cur && cur.menu === menu) return; // Heartbeat ซ้ำเมนูเดิม ไม่นับซ้ำ
      if (cur && now - cur.since <= MENU_MIN_STAY_SEC * 1000 && cur.idPromise) { // เมนูก่อนหน้าอยู่ไม่เกิน 10 วิ = คลิกผ่าน -> ลบรายการทิ้ง
        cur.idPromise.then((id) => { if (id) pool.query("DELETE FROM activity_log WHERE id = $1", [id]).catch(() => {}); });
      }
      const entry = { menu, since: now, idPromise: null };
      entry.idPromise = logActivity(user, "MENU_ENTER", menu);
      lastMenuByUser.set(user, entry);
    } catch (e) { console.error("[activity] menu enter error:", e.message); }
  });
  next();
});

// MARKER_APP_GZIP_JSON_V1 -- gzip response JSON ของ GET (>1KB) เมื่อ Client รองรับ: ลดขนาดข้อมูลที่ส่งผ่านเครือข่ายมาก (rows/attachments ก้อนใหญ่)
import zlib from "zlib";
app.use((req, res, next) => {
  if (req.method !== "GET") return next();
  if (!/\bgzip\b/.test(String(req.headers["accept-encoding"] || ""))) return next();
  const origJson = res.json.bind(res);
  res.json = (body) => {
    if (res.headersSent) return origJson(body);
    let str;
    try { str = JSON.stringify(body); } catch (e) { return origJson(body); }
    if (typeof str !== "string" || str.length < 1024) return origJson(body);
    zlib.gzip(Buffer.from(str, "utf8"), { level: 5 }, (err, buf) => {
      if (err || res.headersSent) return origJson(body);
      res.set("Content-Type", "application/json; charset=utf-8");
      res.set("Content-Encoding", "gzip");
      res.set("Vary", "Accept-Encoding");
      res.set("Content-Length", String(buf.length));
      res.end(buf);
    });
    return res;
  };
  next();
});

const SERVER_START = Date.now();

// ── คำนวณ CPU % ปัจจุบันของทั้งเครื่อง ── MARKER_SYNC_GETCURRENTCPU_APP_V1 ──
// getCurrentCpu() ย้ายไปอยู่ที่ System.js เพียงจุดเดียว (import ด้านบน)
// เดิมมีฟังก์ชันนี้ซ้ำกัน 2 ชุด (คนละ Cache) ทำให้ /health (Deploy Monitor)
// กับ /api/system/cpu-current (CPU Dashboard) รายงานค่า CPU ไม่ตรงกัน

// ── cache git info ตอน startup ครั้งเดียว ────────────────────────────────
let gitInfo = { commit: null, branch: null, author: null, message: null };
try {
  gitInfo.commit  = execSync("git -C D:/fastapn-link3ase/my-app rev-parse --short HEAD",      { timeout: 3000 }).toString().trim();
  gitInfo.branch  = execSync("git -C D:/fastapn-link3ase/my-app rev-parse --abbrev-ref HEAD", { timeout: 3000 }).toString().trim();
  gitInfo.author  = execSync("git -C D:/fastapn-link3ase/my-app log -1 --format=%an",         { timeout: 3000 }).toString().trim();
  gitInfo.message = execSync("git -C D:/fastapn-link3ase/my-app log -1 --format=%s",          { timeout: 3000 }).toString().trim();
} catch {}

app.get("/health", async (req, res) => {
  try {
    const totalMem = os.totalmem();
    const freeMem  = os.freemem();
    const usedMem  = totalMem - freeMem;
    const ramPct   = Math.round((usedMem / totalMem) * 100);

    let dbLatency = null;
    let dbStatus  = "error";
    try {
      const t0 = Date.now();
      await pool.query("SELECT 1");
      dbLatency = Date.now() - t0;
      dbStatus  = "ok";
    } catch {}

    res.json({
      status: "ok",
      uptime: Math.round((Date.now() - SERVER_START) / 1000),
      startedAt: new Date(SERVER_START).toISOString(), // MARKER_HEALTH_STARTEDAT_V1 -- เวลา Restart ล่าสุดจริง ให้ Frontend เทียบ Sync กับ Build Time
      ram: { pct: ramPct, used: Math.round(usedMem / 1024 / 1024), total: Math.round(totalMem / 1024 / 1024) },
      cpu: { pct: await getCurrentCpu() }, // MARKER_FIX_GETCURRENTCPU_ASYNC_APP
      db:  { status: dbStatus, latency: dbLatency },
      git: gitInfo,
    });
  } catch (err) {
    res.status(500).json({ status: "error", error: err.message });
  }
});

// MARKER_APP_VERSION_ENDPOINT_LIGHTWEIGHT_V1
// -- Endpoint เบาๆ เฉพาะเช็ค Version -- ไม่มี CPU Sampling/DB Query เลย ตอบกลับทันที --
// -- (ต่างจาก /health ที่มี getCurrentCpu() ใช้เวลาอย่างน้อย ~3 วิเวลา Cache หมดอายุ) --
app.get("/version", (req, res) => {
  res.json({
    startedAt: new Date(SERVER_START).toISOString(),
    git: gitInfo,
  });
});

// Public endpoint สำหรับเช็ค maintenance mode (ไม่ต้อง login)
app.get("/api/public/maintenance", async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT key, value FROM system_settings WHERE key IN ('maintenance_mode', 'maintenance_message')`
    );
    const result = {};
    rows.forEach(r => result[r.key] = r.value);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Auth routes (public — ไม่ต้อง token)
app.use("/api/auth", authRouter);

// -- POST /api/internal/broadcast -- public เหมือนกัน (ไม่ผ่าน verifyAuthLocal)
// เพราะเป็น internal service เรียกเอง (เช่น ocr_worker_v2.py คนละ process/ภาษา
// ไม่มี user session/login token) ต้องอยู่ก่อน global auth middleware ด้านล่าง
// ไม่งั้นจะโดน verifyAuthLocal บังคับ auth ไปด้วยทั้งที่ route ไม่ได้เรียกเอง
// ความปลอดภัย: จำกัดเฉพาะ request จาก localhost เท่านั้น
app.post("/api/internal/broadcast", (req, res) => {
  const ip = req.ip || req.connection?.remoteAddress || "";
  const isLocalhost = ip === "127.0.0.1" || ip === "::1" || ip === "::ffff:127.0.0.1";
  if (!isLocalhost) {
    return res.status(403).json({ error: "internal endpoint only" });
  }
  const { event, ...data } = req.body;
  if (!event) return res.status(400).json({ error: "event required" });
  wsBroadcast(event, data);
  res.json({ ok: true });
});

// ทุก route ตั้งแต่บรรทัดนี้ลงไปต้อง login ก่อน
app.use(verifyAuthLocal, attachAppRole);
app.use("/api/ocr", ocrRoutes);
app.use("/api/ap/period", apPeriodRouter);
app.use("/api/vat/period", vatPeriodRouter);
app.use("/api/ie/period", iePeriodRouter);
app.use("/api/system", systemRouter);
app.use("/api/file-storage", fileStorageRouter);
app.use("/api/vat-export", vatExportRouter); // MARKER_APP_VAT_EXPORT_ROUTER_V1
app.use("/api/ie-export", ieExportRouter); // MARKER_APP_IE_EXPORT_ROUTER_V1
app.use("/api/favorite", favoriteRouter);
app.use("/api/batch-comments", batchCommentsRouter);
app.use("/api/legacy-import", legacyImportRouter);
app.use("/api", invoiceHistoryRouter);
app.use("/api/invoice-flows", invoiceFlowsRouter);
app.use("/api/excel", excelReportRouter);
app.use("/api/docenter", docenterOcrRouter);
app.use("/api/batch-control", batchControlRouter);
app.use("/api/vat-reconcile", vatReconcileRouter); // MARKER_APP_MOUNT_VAT_RECONCILE_ROUTER_V1
app.use("/api/ap-reconcile", apReconcileRouter); // MARKER_APP_MOUNT_AP_RECONCILE_ROUTER_V1
app.use("/api/support", supportRouter); // MARKER_MOUNT_SUPPORT_ROUTER_V1

// -- POST /api/ws-notify � Frontend ????????? action ????? ? broadcast ????? client --
// MARKER_APP_WSNOTIFY_GENERIC_PAYLOAD_V1
// -- ?????? Hardcode ?????? batch_id/status ???? Forward ??? Field ???????? --
// -- (Generic) � Field ???????? email/user_id/folder_key ?????????????????? --
app.post("/api/ws-notify", verifyAuthLocal, (req, res) => {
  const { event, ...data } = req.body;
  if (!event) return res.status(400).json({ error: "event required" });
  wsBroadcast(event, data);
  res.json({ ok: true });
});

// MARKER_APP_BATCH_RECYCLE_BUNDLE_V1
// -- POST /api/batch-recycle-bundle � ??? batch_list + bucket_list (Invoice --
// -- ?????????????) ???? Recycle Bin ??????????? (1 Batch = 1 ?????? ?????? --
// -- ??????? Invoice) � ??????????????????????????? My Jobs � ???????????? --
// -- ??? ??? Log ???? recycle_bin ???????? ???? Frontend ????????????????? --
// -- ?hard=true (???? Soft Delete ???? ??? Insert ???) ---------------------
app.post("/api/batch-recycle-bundle", verifyAuthLocal, async (req, res, next) => {
  try {
    const { batch_id } = req.body;
    if (!batch_id) return res.status(400).json({ error: "batch_id required" });

    const { rows: batchRows } = await pool.query(
      `SELECT * FROM batch_list WHERE batch_id = $1`,
      [batch_id]
    );
    if (!batchRows[0]) return res.status(404).json({ error: "????? Batch ???" });

    const { rows: invoiceRows } = await pool.query(
      `SELECT * FROM bucket_list WHERE batch_id = $1`,
      [batch_id]
    );

    // ??? username ???????? (??? attachRole.js patch66) Fallback ???? email
    const deletedBy = req.user?.username || req.user?.email || "unknown";
    const bundledData = { batch: batchRows[0], invoices: invoiceRows };

    await pool.query(
      `INSERT INTO recycle_bin (source_table, source_id, source_key, data, deleted_by, deleted_at)
       VALUES ('batch_list', $1, $2, $3, $4, NOW())`,
      [batchRows[0].id, batch_id, JSON.stringify(bundledData), deletedBy]
    );

    res.json({ ok: true, invoiceCount: invoiceRows.length });
  } catch (err) {
    next(err);
  }
});

app.use("/api/account_list",        createTableRouter("account_list"));
app.use("/api/branch_list",         createTableRouter("branch_list"));
app.use("/api/company_list",        createTableRouter("company_list"));
// MARKER_APP_VAT_WATCHLIST_AGING_SUMMARY_V1
// -- GET /api/vat_watchlist_report/aging_summary -- นับจำนวนแถวแยกตาม BU x Aging Category --
// -- (SQL GROUP BY ที่ Generic Table Router ไม่รองรับ) -- ต้องอยู่ก่อน Generic Mount ด้านล่าง --
// -- ไม่งั้น Generic Router จะดักจับ Path นี้ไปก่อน (Express Match ตามลำดับ Register) --
app.get("/api/vat_watchlist_report/aging_summary", async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT bu, aging_label, COUNT(*)::int AS count
       FROM vat_watchlist_report
       WHERE status NOT IN ('type_a', 'type_b', 'type_f') -- MARKER_APP_TYPE_ABF_STATUS_V1
       GROUP BY bu, aging_label`
    );
    res.json(rows);
  } catch (err) {
    console.error("vat_watchlist_report aging_summary error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});
// MARKER_APP_NOTES_CLEANUP_UNMATCHED_V1
// -- ลบ Note ที่ note_at เกิน 30 วัน + ไม่ Match กับแถวไหนใน vat_watchlist_report --
// -- เลยแล้ว (Invoice สมบูรณ์ไปแล้ว ไม่อยู่ใน Incomplete Report อีกต่อไป) --
async function checkAndCleanupUnmatchedNotes() { // MARKER_APP_NOTES_CLEANUP_UNMATCHED_SINCE_V1
  // ── ขั้นตอน 1: Note ที่เพิ่ง Unmatch ครั้งแรก -> บันทึกวันที่เริ่ม Unmatch ──
  await pool.query(`
    UPDATE vat_watchlist_notes n
    SET unmatched_since = NOW()
    WHERE unmatched_since IS NULL
    AND NOT EXISTS (
      SELECT 1 FROM vat_watchlist_report r
      WHERE r.bu = n.bu AND r.invoice_ref = n.invoice_ref AND r.supplier_code = n.supplier_code
    )
  `);
  // ── ขั้นตอน 2: Note ที่กลับมา Match อีกครั้ง -> Reset unmatched_since ──
  await pool.query(`
    UPDATE vat_watchlist_notes n
    SET unmatched_since = NULL
    WHERE unmatched_since IS NOT NULL
    AND EXISTS (
      SELECT 1 FROM vat_watchlist_report r
      WHERE r.bu = n.bu AND r.invoice_ref = n.invoice_ref AND r.supplier_code = n.supplier_code
    )
  `);
  // MARKER_APP_NOTES_UNMATCH_WARNING_V1
  // ── ขั้นตอน 2.5: Note ที่ Unmatch ใกล้ครบ 30 วัน (เหลือไม่เกิน 24 ชม.) -> แจ้งเตือน Bell ──
  const { rows: expiringNotes } = await pool.query(`
    SELECT id FROM vat_watchlist_notes
    WHERE unmatched_since IS NOT NULL
    AND unmatched_since < NOW() - INTERVAL '29 days'
    AND unmatched_since >= NOW() - INTERVAL '30 days'
    AND remark = 'Check Return' -- MARKER_APP_NOTES_CLEANUP_CHECKRETURN_ONLY_V1
  `);
  if (expiringNotes.length > 0) {
    await pool.query(`DELETE FROM notifications WHERE category = 'VAT_NOTE_UNMATCH_WARNING'`);
    await pool.query(
      `INSERT INTO notifications (title, message, category, action_type, target_permission, created_by, read_by)
       VALUES ($1, $2, 'VAT_NOTE_UNMATCH_WARNING', 'NOTE_UNMATCH_WARNING', 'VAT', 'system (auto)', '[]'::jsonb)`,
      [
        `Note ใกล้ถูกลบอัตโนมัติ (${expiringNotes.length} รายการ)`,
        `มี Note จำนวน ${expiringNotes.length} รายการ ที่ Unmatch ต่อเนื่องมาเกือบ 30 วัน จะถูกลบอัตโนมัติภายใน 24 ชม. ถ้ายังไม่มีการ Match กลับมา`,
      ]
    );
  }
  // ── ขั้นตอน 3: Note ที่ Unmatch ต่อเนื่องเกิน 30 วัน -> ลบทิ้ง ──
  const result = await pool.query(`
    DELETE FROM vat_watchlist_notes
    WHERE unmatched_since IS NOT NULL
    AND unmatched_since < NOW() - INTERVAL '30 days'
    AND remark = 'Check Return' -- MARKER_APP_NOTES_CLEANUP_CHECKRETURN_ONLY_V1
    RETURNING id
  `);
  if (result.rowCount > 0) {
    console.log(`[checkAndCleanupUnmatchedNotes] Deleted ${result.rowCount} notes unmatched for 30+ days`);
  }
}

// MARKER_APP_VAT_WATCHLIST_REPLACE_BU_TRANSACTION_V1
// -- POST /api/vat_watchlist_report/replace_bu -- Delete BU เก่า + Insert ข้อมูลใหม่ --
// -- ทั้งหมดในธุรกรรมเดียวกัน (BEGIN...COMMIT / ROLLBACK) กัน Delete สำเร็จ --
// -- แต่ Insert ไม่ครบ (Network ขาด/Server พังกลางทาง) -- ต้องอยู่ก่อน Generic Mount --
const VAT_REPORT_INSERT_COLUMNS = [
  'doc_date','doc_no','site','pay_group','branch','tax_type','invoice_ref','supplier_code',
  'vendor_name','phone','payment_date','check_date','check_no','receive_doc_date','receive_doc_no',
  'exp_amount','exp_vat','avg_amount','avg_vat','ap_source','ap_batch_name','bu','bus_type','sub_type',
  'payment_type','related_persons','period','aging_months','aging_label','status',
];

function buildVatReportBulkInsert(rows) {
  const cols = VAT_REPORT_INSERT_COLUMNS;
  const values = [];
  const placeholders = rows.map((row, i) => {
    const base = i * cols.length;
    const ph = cols.map((_, j) => `$${base + j + 1}`).join(', ');
    cols.forEach((col) => values.push(row[col] === undefined ? null : row[col]));
    return `(${ph})`;
  }).join(', ');
  const sql = `INSERT INTO vat_watchlist_report (${cols.join(', ')}) VALUES ${placeholders}`;
  return { sql, values };
}

// MARKER_VATWATCHLISTOPS_OLDINCOMPLETE_REF_JOIN_V1
// -- Sync 2 คอลัมน์ old_ref_check_no / old_ref_pay_date บน vat_watchlist_report --
// -- จาก vat_watchlist_old_incomplete_ref (Join Key 4 ช่อง: bu+invoice_ref+supplier_code+exp_amount+exp_vat) --
// -- เรียกทุกครั้งหลัง Insert ข้อมูล Incomplete ใหม่ (replace_bu) และตอน Confirm Save จากหน้า Old Incomplete --
// -- Ref Table ไม่เคยถูกแตะตอน Delete+Insert ปกติ ทำให้ Invoice ที่หายไปแล้วโผล่กลับมาใหม่ ก็ยังได้ Ref คืนอัตโนมัติ --
async function applyOldIncompleteRefJoin(client, busFilter, excludeType = false) { // MARKER_APP_REPLACE_BU_TYPE_UNTOUCHED_V1 -- excludeType=true (เรียกจาก replace_bu) ไม่แตะแถว Type A/B/F
  const params = [];
  let busClause = "";
  if (Array.isArray(busFilter) && busFilter.length > 0) {
    params.push(busFilter);
    busClause = "AND r.bu = ANY($1::text[])";
  }
  await client.query(
    `UPDATE vat_watchlist_report r
     SET old_ref_check_no = ref.check_no,
         old_ref_pay_date = ref.payment_date_old
     FROM vat_watchlist_old_incomplete_ref ref
     WHERE r.bu = ref.bu
       AND r.invoice_ref = ref.invoice_ref
       AND r.supplier_code = ref.supplier_code
       AND ROUND(r.exp_amount::numeric, 2) = ROUND(ref.exp_amount, 2)
       AND ROUND(r.exp_vat::numeric, 2) = ROUND(ref.exp_vat, 2)
       ${busClause}
       ${excludeType ? "AND COALESCE(r.status, '') NOT IN ('type_a','type_b','type_f')" : ''}`,
    params
  );
}

// MARKER_APP_VAT_WATCHLIST_REPORT_JUNK_ROW_GUARD_V2 — ตามที่ขอ "ไม่ว่าจะทำ Watchlist หรือว่าอะไรก็ตาม"
// -- แก้จาก V1: V1 เข้าใจผิดว่า "Total Group Branch" เป็นแถว Junk แยกต่างหาก เลยกรองทั้ง Row ทิ้ง
// ไปเลย แต่จากไฟล์ตัวอย่างจริงที่ส่งมา (a25471a1 / acc870aa) พบว่า Row เหล่านี้คือ Invoice จริงปกติ
// (มี id/invoice_ref/exp_amount จริง) แค่ vendor_name มีหางของ Footer รายงานเก่า (เส้นประ, "Total
// Group Branch", "รวมทั้งสิ้น", "====", วันที่, เลขหน้า) ติดมาด้วย -- ถ้ากรองทั้ง Row ทิ้งจะเสีย
// Invoice จริงไปเกือบทั้งตาราง เปลี่ยนมาเป็น "ตัดหาง" ออกจาก vendor_name แค่ Field เดียว เก็บ Row ไว้
// ครบ ไม่ว่าจะมาจาก Excel/Report ของ BU ไหนก็ตามที่ยิงเข้า replace_bu (ประตูทางเข้าหลักของ Watchlist)
app.post("/api/vat_watchlist_report/replace_bu", checkPermission("vat_watchlist_report", "write"), async (req, res) => {
  const { bus, rows: rawRows } = req.body || {};
  if (!Array.isArray(bus) || bus.length === 0) {
    return res.status(400).json({ error: "bus (array) is required" });
  }
  if (!Array.isArray(rawRows)) {
    return res.status(400).json({ error: "rows (array) is required" });
  }
  // MARKER_APP_REPLACE_BU_LATE_ASOF_GUARD_V1 -- ไฟล์ที่ As-Of เป็นเดือนที่ปิด Period แล้ว ห้ามเข้า Report (ใช้ได้เฉพาะอัปเดต Freeze ผ่าน /api/vat_freeze/late_update) -- Frontend ส่ง as_of_month มา; ไม่ส่ง = ไม่ตรวจ
  const asOfMonthIn = req.body && req.body.as_of_month;
  if (asOfMonthIn) {
    if (!/^\d{4}-\d{2}$/.test(String(asOfMonthIn))) return res.status(400).json({ error: "as_of_month ต้องเป็นรูปแบบ YYYY-MM" });
    const closedQ = await pool.query("SELECT value FROM system_settings WHERE key = 'vat_period_month'");
    const closedMonth = closedQ.rows[0] && closedQ.rows[0].value;
    if (closedMonth && String(asOfMonthIn) <= closedMonth) {
      return res.status(409).json({ error: `ข้อมูล ณ เดือน ${asOfMonthIn} เป็นเดือนที่ปิด Period แล้ว ห้ามนำเข้า Report (ใช้อัปเดต Freeze ได้เท่านั้น)`, code: "LATE_ASOF" });
    }
  }
  // ทำความสะอาด vendor_name ก่อน Insert -- เก็บ Row ไว้ครบทุก Row แค่ตัดหาง Junk ออกจาก vendor_name
  const rows = rawRows.map((r) => {
    if (r && typeof r.vendor_name === "string") {
      return { ...r, vendor_name: cleanJunkVendorNameJs(r.vendor_name) };
    }
    return r;
  });
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("SET LOCAL lock_timeout = '20s'"); // MARKER_APP_REPLACE_BU_TIMING_LOCK_V1 -- ถ้ามี Transaction อื่นล็อกตารางค้างอยู่ ให้ Error ชัดเจนภายใน 20 วินาที แทนที่จะค้างเงียบ
    await client.query("SET LOCAL gin_pending_list_limit = 262144"); // MARKER_APP_REPLACE_BU_GIN_PENDING_V1 -- ตาราง vat_watchlist_report มี GIN Trigram Index 7 ตัว (invoice_ref/supplier_code/vendor_name/check_no/receive_doc_no/doc_no/branch) -- Insert ทีละหมื่นแถวช้ามาก ขยาย Pending List (256MB) ให้ GIN เก็บรวมไว้ก่อนแล้วค่อย Merge ทีหลัง (Autovacuum/VACUUM จัดการต่อ)
    await client.query("SET LOCAL work_mem = '256MB'"); // MARKER_APP_REPLACE_BU_GIN_PENDING_V1 -- ใช้ตอน GIN Flush Pending List ถ้าเกิดขึ้นระหว่าง Transaction
    const __t0 = Date.now(); const __lap = (label) => console.log(`[replace_bu] ${label}: ${Date.now() - __t0} ms (bus=${bus.length}, rows=${rows.length})`); // MARKER_APP_REPLACE_BU_TIMING_LOCK_V1
    // MARKER_APP_REPLACE_BU_KEEP_SEND_FP_V1 -- เก็บรายการที่ส่งไป Bucket ของ Full Page (status 'send_fp') ไว้ก่อนลบ แล้วคืนสถานะให้แถวที่ Match ใน Incomplete ใหม่ (bu+invoice_ref+supplier_code)
    const keepSendFp = await client.query("SELECT bu, invoice_ref, supplier_code, status FROM vat_watchlist_report WHERE bu = ANY($1::text[]) AND status IN ('send_fp', 'draft', 'fu-draft')", [bus]); // MARKER_APP_REPLACE_BU_KEEP_DRAFT_V1 -- เก็บ draft/fu-draft ด้วย: งานที่กำลังทำอยู่ (Popvat/Simple/ADI Draft) ต้องคงสถานะเดิมแม้มีการ Import ทับ
    // MARKER_APP_TYPE_ABF_STATUS_V1 -- เก็บแถว Popvat Type A/B/F ไว้ก่อนลบ (ไม่ถูกล้างเมื่อ Upload Incomplete ใหม่)
    const keepTypeCnt = await client.query("SELECT COUNT(*)::int AS n FROM vat_watchlist_report WHERE bu = ANY($1::text[]) AND status IN ('type_a','type_b','type_f')", [bus]); // MARKER_APP_REPLACE_BU_TYPE_UNTOUCHED_V1 -- แถว Type A/B/F ไม่ถูกแตะเลย (ไม่ลบ/ไม่ Insert กลับ/ไม่ผ่าน Trigger/ไม่ถูก Join) นับไว้แค่ส่งกลับ
    __lap('keep rows saved');
    const __delRes = await client.query("DELETE FROM vat_watchlist_report WHERE bu = ANY($1::text[]) AND COALESCE(status, '') NOT IN ('type_a','type_b','type_f')", [bus]); // MARKER_APP_REPLACE_BU_TIMING_LOCK_V1 MARKER_APP_REPLACE_BU_TYPE_UNTOUCHED_V1 -- ไม่ลบแถว Type A/B/F -- เก็บจำนวนที่ลบไว้ส่งกลับ (หน้าเว็บไม่ต้องดึงทั้งตารางมานับเอง)
    __lap(`deleted ${__delRes.rowCount}`);
    const REPLACE_BU_CHUNK_SIZE = 1000; // 1000 แถว x 30 คอลัมน์ = 30,000 Param (ไม่ชน Limit 65,535)
    for (let i = 0; i < rows.length; i += REPLACE_BU_CHUNK_SIZE) {
      const chunk = rows.slice(i, i + REPLACE_BU_CHUNK_SIZE);
      if (chunk.length === 0) continue;
      const { sql, values } = buildVatReportBulkInsert(chunk);
      await client.query(sql, values);
    }
    __lap('inserted');
    if (keepTypeCnt.rows[0].n > 0) { // MARKER_APP_REPLACE_BU_TYPE_UNTOUCHED_V1 -- แถว pending ใหม่ที่ Key ซ้ำกับแถว Type เดิม ตัดทิ้ง (แถว Type เดิมคงอยู่ตามเดิม)
      await client.query("DELETE FROM vat_watchlist_report n USING vat_watchlist_report k WHERE n.bu = ANY($1::text[]) AND n.status = 'pending' AND k.bu = n.bu AND k.status IN ('type_a','type_b','type_f') AND k.invoice_ref = n.invoice_ref AND k.supplier_code IS NOT DISTINCT FROM n.supplier_code", [bus]);
    }
    await applyOldIncompleteRefJoin(client, bus, true); // MARKER_VATWATCHLISTOPS_OLDINCOMPLETE_REF_JOIN_CALL_V1
    __lap('ref join done');
    if (keepSendFp.rowCount > 0) {
      await client.query(
        `UPDATE vat_watchlist_report r SET status = k.status
         FROM UNNEST($1::text[], $2::text[], $3::text[], $4::text[]) AS k(bu, invoice_ref, supplier_code, status)
         WHERE r.bu = k.bu AND r.invoice_ref = k.invoice_ref AND r.supplier_code IS NOT DISTINCT FROM k.supplier_code
           AND r.status = 'pending'`,
        [keepSendFp.rows.map((x) => x.bu), keepSendFp.rows.map((x) => x.invoice_ref), keepSendFp.rows.map((x) => x.supplier_code), keepSendFp.rows.map((x) => x.status)]
      );
    }
    for (const __buSync of bus) { await syncDraftStatusForBu(client, __buSync); } // MARKER_APP_REPLACE_BU_SYNC_LINKED_STATUS_V1 -- หลัง Import ทับ ดึงสถานะแถวที่เหลือกลับจากตารางที่ผูกกับ Report (Popvat Draft -> draft/fu-draft, Note Accept -> Aging) ใน Transaction เดียวกัน (Type A/B/F ถูกกันไว้ในฟังก์ชันนี้อยู่แล้ว)
    __lap('linked status synced');
    await client.query("COMMIT");
    __lap('commit');
    res.json({ success: true, deleted_bu: bus, deleted_count: __delRes.rowCount, inserted: rows.length, kept_type: keepTypeCnt.rows[0].n });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("vat_watchlist_report replace_bu error:", err);
    res.status(500).json({ error: "Internal server error", detail: err.message });
  } finally {
    client.release();
  }
});
// MARKER_VATWATCHLISTOPS_OLDINCOMPLETE_MATCH_PREVIEW_V1
// -- POST /api/vat_watchlist_old_incomplete_ref/match_preview --
// -- รับแถว Old Incomplete ที่ Frontend Parse + หา BU มาแล้ว -> Match กับ New Incomplete ปัจจุบัน --
// -- คืนเฉพาะแถวที่ Match ได้ พร้อมข้อมูลจริงจาก vat_watchlist_report ของแถวนั้น (ไม่ Insert อะไรทั้งสิ้น แค่ดูผลก่อน) --
function buildOldIncompleteMatchInput(rows) {
  const bu = [], invoiceRef = [], supplierCode = [], expAmount = [], expVat = [], checkNo = [], paymentDateOld = [], vendorNameOld = [];
  for (const row of rows) {
    const cn = String((row && row.check_no) || "").trim();
    if (!cn) continue; // MARKER_VATWATCHLISTOPS_OLDINCOMPLETE_REQUIRE_CHECKNO_V1 -- เฉพาะแถวที่มีเลขที่เช็คแล้วเท่านั้น
    bu.push(row.bu);
    invoiceRef.push(row.invoice_ref);
    supplierCode.push(row.supplier_code);
    expAmount.push(row.exp_amount);
    expVat.push(row.exp_vat);
    checkNo.push(cn);
    paymentDateOld.push(row.payment_date_old || null);
    vendorNameOld.push(row.vendor_name || null); // MARKER_VATWATCHLISTOPS_OLDINCOMPLETE_PREVIEW_VENDORNAME_V1 -- ชื่อผู้ขายจากไฟล์ Old Incomplete เอง (ไม่ได้ใช้ใน confirm_save เพราะ Ref Table ไม่มี Column นี้ -- ใช้เฉพาะ match_preview เป็น Fallback ให้ใบพี่น้อง)
  }
  return { bu, invoiceRef, supplierCode, expAmount, expVat, checkNo, paymentDateOld, vendorNameOld };
}

const OLD_INCOMPLETE_MATCH_SQL = `
  SELECT
    r.bu, r.invoice_ref, r.supplier_code, r.vendor_name, r.exp_amount, r.exp_vat,
    input.check_no AS old_ref_check_no, input.payment_date_old AS old_ref_pay_date
  FROM UNNEST($1::text[], $2::text[], $3::text[], $4::numeric[], $5::numeric[], $6::text[], $7::date[])
    AS input(bu, invoice_ref, supplier_code, exp_amount, exp_vat, check_no, payment_date_old)
  JOIN vat_watchlist_report r
    ON r.bu = input.bu
    AND r.invoice_ref = input.invoice_ref
    AND r.supplier_code = input.supplier_code
    AND ROUND(r.exp_amount::numeric, 2) = ROUND(input.exp_amount, 2)
    AND ROUND(r.exp_vat::numeric, 2) = ROUND(input.exp_vat, 2)
  ORDER BY r.bu, r.invoice_ref
`;

// MARKER_VATWATCHLISTOPS_OLDINCOMPLETE_PREVIEW_SIBLING_PULL_V1
// -- Preview แบบเดียวกับ confirm_save เป๊ะ: หา Direct Match ก่อน (bu+check_no ที่ Match ได้จริงอย่างน้อย 1 ใบ) --
// -- แล้วดึงทุกแถวใน Input ทั้งก้อนที่ใช้เลขที่เช็คเดียวกัน (ใบพี่น้อง) มาโชว์ด้วย -- ให้ตัวเลขที่ AP เห็นก่อนกด --
// -- Confirm ตรงกับจำนวนที่จะถูกบันทึกจริง (savedCount) ไม่ใช่แค่ directMatchCount เหมือนเดิม --
// -- is_direct_match: true = Match ตรงกับ Incomplete ปัจจุบันเป๊ะ, false = ใบพี่น้อง (Reference เท่านั้น --
// -- ไม่ได้ Match กับ Incomplete ปัจจุบัน จะไม่ถูกเขียนลง old_ref_check_no ของแถวไหนใน vat_watchlist_report เลย) --
const OLD_INCOMPLETE_MATCH_SIBLING_SQL = `
  WITH input AS (
    SELECT * FROM UNNEST($1::text[], $2::text[], $3::text[], $4::numeric[], $5::numeric[], $6::text[], $7::date[], $8::text[])
      AS t(bu, invoice_ref, supplier_code, exp_amount, exp_vat, check_no, payment_date_old, vendor_name_old)
  ),
  direct AS (
    SELECT i.bu, i.invoice_ref, i.supplier_code, i.check_no, i.payment_date_old, r.vendor_name, r.exp_amount, r.exp_vat
    FROM input i
    JOIN vat_watchlist_report r
      ON r.bu = i.bu AND r.invoice_ref = i.invoice_ref AND r.supplier_code = i.supplier_code
      AND ROUND(r.exp_amount::numeric, 2) = ROUND(i.exp_amount, 2)
      AND ROUND(r.exp_vat::numeric, 2) = ROUND(i.exp_vat, 2)
  ),
  confirmed_checks AS (
    SELECT DISTINCT bu, check_no FROM direct
  )
  SELECT
    i.bu, i.invoice_ref, i.supplier_code,
    -- MARKER_VATWATCHLISTOPS_OLDINCOMPLETE_PREVIEW_VENDORNAME_V1 -- Match ตรง ใช้ชื่อจาก vat_watchlist_report ปัจจุบัน (สด/แม่นสุด) -- ใบพี่น้อง Fallback ไปใช้ชื่อจากไฟล์ Old Incomplete เอง -- ไม่มีทั้งคู่ ว่างเปล่า
    COALESCE(d.vendor_name, NULLIF(i.vendor_name_old, ''), '') AS vendor_name,
    COALESCE(d.exp_amount, i.exp_amount) AS exp_amount,
    COALESCE(d.exp_vat, i.exp_vat) AS exp_vat,
    i.check_no AS old_ref_check_no, i.payment_date_old AS old_ref_pay_date,
    (d.invoice_ref IS NOT NULL) AS is_direct_match
  FROM input i
  JOIN confirmed_checks c ON c.bu = i.bu AND c.check_no = i.check_no
  LEFT JOIN direct d ON d.bu = i.bu AND d.invoice_ref = i.invoice_ref AND d.supplier_code = i.supplier_code
  ORDER BY i.bu, i.check_no, i.invoice_ref
`;

app.post("/api/vat_watchlist_old_incomplete_ref/match_preview", checkPermission("vat_watchlist_report", "write"), async (req, res) => {
  const { rows } = req.body || {};
  if (!Array.isArray(rows)) {
    return res.status(400).json({ error: "rows (array) is required" });
  }
  try {
    const input = buildOldIncompleteMatchInput(rows);
    const { rows: matched } = await pool.query(OLD_INCOMPLETE_MATCH_SIBLING_SQL, [
      input.bu, input.invoiceRef, input.supplierCode, input.expAmount, input.expVat, input.checkNo, input.paymentDateOld, input.vendorNameOld, // MARKER_VATWATCHLISTOPS_OLDINCOMPLETE_PREVIEW_VENDORNAME_V1
    ]);
    const directMatchCount = matched.filter((m) => m.is_direct_match).length;
    const siblingCount = matched.length - directMatchCount;
    const byBuMap = {};
    for (const m of matched) byBuMap[m.bu] = (byBuMap[m.bu] || 0) + 1;
    const byBu = Object.keys(byBuMap).sort().map((bu) => ({ bu, count: byBuMap[bu] }));
    res.json({
      success: true,
      totalInput: rows.length,
      totalWithCheckNo: input.bu.length,
      matchedCount: matched.length,
      directMatchCount,
      siblingCount,
      byBu,
      matched,
    });
  } catch (err) {
    console.error("vat_watchlist_old_incomplete_ref match_preview error:", err);
    res.status(500).json({ error: "Internal server error", detail: err.message });
  }
});

// MARKER_VATWATCHLISTOPS_OLDINCOMPLETE_CONFIRM_SAVE_V1
// -- POST /api/vat_watchlist_old_incomplete_ref/confirm_save --
// -- Re-match ซ้ำฝั่ง Backend จาก rows ดิบ (ไม่เชื่อผล Match ที่ Frontend ส่งมาเฉยๆ) --
// -- Insert เข้า Ref Table ถาวร (Upsert กันซ้ำด้วย Key 4 ช่อง) + Update 2 คอลัมน์บน vat_watchlist_report ทันที ในธุรกรรมเดียว --
app.post("/api/vat_watchlist_old_incomplete_ref/confirm_save", checkPermission("vat_watchlist_report", "write"), async (req, res) => {
  const { rows } = req.body || {};
  if (!Array.isArray(rows) || rows.length === 0) {
    return res.status(400).json({ error: "rows (array) is required" });
  }
  const input = buildOldIncompleteMatchInput(rows);
  if (input.bu.length === 0) {
    return res.json({ success: true, matchedCount: 0, savedCount: 0 });
  }
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    // MARKER_VATWATCHLISTOPS_OLDREF_SIBLING_PULL_V1
    // -- นับจำนวน (bu+check_no) ที่ยืนยัน Match กับ Incomplete ปัจจุบันได้จริง (Direct Match) ก่อน Insert จริง --
    // -- ไว้ Report แยกจาก savedCount (ที่รวมใบพี่น้องที่ดึงมาเพิ่มด้วย) --
    const { rows: directRows } = await client.query(
      `
      SELECT DISTINCT i.bu, i.check_no
      FROM UNNEST($1::text[], $2::text[], $3::text[], $4::numeric[], $5::numeric[], $6::text[], $7::date[])
        AS i(bu, invoice_ref, supplier_code, exp_amount, exp_vat, check_no, payment_date_old)
      JOIN vat_watchlist_report r
        ON r.bu = i.bu AND r.invoice_ref = i.invoice_ref AND r.supplier_code = i.supplier_code
        AND ROUND(r.exp_amount::numeric, 2) = ROUND(i.exp_amount, 2)
        AND ROUND(r.exp_vat::numeric, 2) = ROUND(i.exp_vat, 2)
      `,
      [input.bu, input.invoiceRef, input.supplierCode, input.expAmount, input.expVat, input.checkNo, input.paymentDateOld]
    );
    const directMatchCount = directRows.length;
    const { rows: saved } = await client.query(
      `
      WITH input AS (
        SELECT * FROM UNNEST($1::text[], $2::text[], $3::text[], $4::numeric[], $5::numeric[], $6::text[], $7::date[])
          AS t(bu, invoice_ref, supplier_code, exp_amount, exp_vat, check_no, payment_date_old)
      ),
      confirmed_checks AS (
        -- MARKER_VATWATCHLISTOPS_OLDREF_SIBLING_PULL_V1 -- (bu+check_no) ที่ยืนยัน Match ได้จริงอย่างน้อย 1 ใบ (เช็คใบนี้ยัง Relevant พอจะเก็บ Reference)
        SELECT DISTINCT i.bu, i.check_no
        FROM input i
        JOIN vat_watchlist_report r
          ON r.bu = i.bu AND r.invoice_ref = i.invoice_ref AND r.supplier_code = i.supplier_code
          AND ROUND(r.exp_amount::numeric, 2) = ROUND(i.exp_amount, 2)
          AND ROUND(r.exp_vat::numeric, 2) = ROUND(i.exp_vat, 2)
      ),
      matched AS (
        -- ดึงทุกแถวใน Input ทั้งก้อนที่ใช้เลขที่เช็คเดียวกับที่ยืนยัน Match แล้วอย่างน้อย 1 ใบ -- แม้บางใบจะไม่ Match กับ
        -- Incomplete ปัจจุบันแล้ว (เช่นจ่ายจบไปแล้ว) ก็ตาม -- เก็บไว้เป็นข้อมูลอ้างอิง (ไม่กระทบ vat_watchlist_report
        -- เพราะ applyOldIncompleteRefJoin Join แบบ Exact 4 ช่อง ใบพวกนี้ไม่มีวัน Match อะไรเพิ่มอยู่แล้ว)
        SELECT DISTINCT i.bu, i.invoice_ref, i.supplier_code, i.exp_amount, i.exp_vat, i.check_no, i.payment_date_old
        FROM input i
        JOIN confirmed_checks c ON c.bu = i.bu AND c.check_no = i.check_no
      )
      INSERT INTO vat_watchlist_old_incomplete_ref (bu, invoice_ref, supplier_code, exp_amount, exp_vat, check_no, payment_date_old)
      SELECT bu, invoice_ref, supplier_code, exp_amount, exp_vat, check_no, payment_date_old FROM matched
      ON CONFLICT ON CONSTRAINT uq_vat_old_incomplete_ref_key
      DO UPDATE SET check_no = EXCLUDED.check_no, payment_date_old = EXCLUDED.payment_date_old, imported_at = now()
      RETURNING bu
      `,
      [input.bu, input.invoiceRef, input.supplierCode, input.expAmount, input.expVat, input.checkNo, input.paymentDateOld]
    );
    const distinctBus = [...new Set(saved.map((r) => r.bu))];
    if (distinctBus.length > 0) {
      await applyOldIncompleteRefJoin(client, distinctBus);
    }
    await client.query("COMMIT");
    res.json({ success: true, matchedCount: input.bu.length, directMatchCount, savedCount: saved.length });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("vat_watchlist_old_incomplete_ref confirm_save error:", err);
    res.status(500).json({ error: "Internal server error", detail: err.message });
  } finally {
    client.release();
  }
});

// MARKER_VATWATCHLISTOPS_OLDREF_LOOKUP_BY_CHECKS_V1
// -- POST /api/vat_watchlist_old_incomplete_ref/lookup_by_checks --
// -- Read-only: รับ [{bu, check_no}, ...] หลายคู่ในคำขอเดียว คืนทุกแถวใน vat_watchlist_old_incomplete_ref --
// -- ที่ตรงกับคู่ไหนก็ได้ (รวมใบที่จ่ายจบไปแล้ว ไม่ได้อยู่ใน Incomplete ปัจจุบันด้วย) --
// -- ใช้โดย Check Return Matching Tier 1.5: เช็คยอดกับ "กลุ่มเต็ม" ของเช็คเดิม เผื่อบางใบจ่ายจบไปแล้วทำให้ยอด --
// -- จากแค่ใบที่เหลือ Incomplete ไม่ครบ --
app.post("/api/vat_watchlist_old_incomplete_ref/lookup_by_checks", checkPermission("vat_watchlist_report", "write"), async (req, res) => {
  const { pairs } = req.body || {};
  if (!Array.isArray(pairs) || pairs.length === 0) {
    return res.json({ success: true, rows: [] });
  }
  const bu = [], checkNo = [];
  const seen = new Set();
  for (const p of pairs) {
    if (!p || !p.bu || !p.check_no) continue;
    const key = `${p.bu}|||${p.check_no}`;
    if (seen.has(key)) continue; // MARKER_VATWATCHLISTOPS_OLDREF_LOOKUP_BY_CHECKS_V1 -- กัน Pair ซ้ำ ไม่ต้องส่งเข้า UNNEST ซ้ำ
    seen.add(key);
    bu.push(p.bu);
    checkNo.push(p.check_no);
  }
  if (bu.length === 0) {
    return res.json({ success: true, rows: [] });
  }
  try {
    const { rows } = await pool.query(
      `
      SELECT DISTINCT ref.bu, ref.invoice_ref, ref.supplier_code, ref.exp_amount, ref.exp_vat, ref.check_no, ref.payment_date_old
      FROM UNNEST($1::text[], $2::text[]) AS pair(bu, check_no)
      JOIN vat_watchlist_old_incomplete_ref ref
        ON ref.bu = pair.bu AND ref.check_no = pair.check_no
      `,
      [bu, checkNo]
    );
    res.json({ success: true, rows });
  } catch (err) {
    console.error("vat_watchlist_old_incomplete_ref lookup_by_checks error:", err);
    res.status(500).json({ error: "Internal server error", detail: err.message });
  }
});
// MARKER_APP_VAT_BACKUP_TAX_INVOICE_PURGE_V1
// -- POST /api/vat_backup_tax_invoice/purge -- ล้างข้อมูลหน้า Tax Invoice (เฉพาะ Owner) -- ต้องอยู่ก่อน Generic Mount --
// -- action: 'options' (นับแยก Source/Status/BU ทั้งตาราง) | 'preview' (นับตามเงื่อนไข) | 'delete' (ลบจริง ต้องส่ง expected_count ตรงกับที่นับสดตอนลบ) --
// -- เงื่อนไข (AND กัน): source_type, status, bu, date_from/date_to (doc_date), older_than_months (doc_date < วันนี้ - N เดือน), all=true (ไม่กรอง ต้องส่งชัดเจน) --
app.post("/api/vat_backup_tax_invoice/purge", async (req, res) => {
  if (req.user?.appRole !== "Owner") {
    return res.status(403).json({ error: "เฉพาะ Owner เท่านั้น" });
  }
  const body = req.body || {};
  const action = body.action || "preview";
  const docDateExpr = "NULLIF(doc_date::text, '')::date";
  try {
    if (action === "options") {
      const [bySource, byStatus, byBu, range] = await Promise.all([
        pool.query("SELECT COALESCE(source_type, '') AS k, COUNT(*)::int AS n FROM vat_backup_tax_invoice GROUP BY 1 ORDER BY n DESC"),
        pool.query("SELECT COALESCE(status, '') AS k, COUNT(*)::int AS n FROM vat_backup_tax_invoice GROUP BY 1 ORDER BY n DESC"),
        pool.query("SELECT COALESCE(bu, '') AS k, COUNT(*)::int AS n FROM vat_backup_tax_invoice GROUP BY 1 ORDER BY k"),
        pool.query("SELECT MIN(" + docDateExpr + ") AS min_date, MAX(" + docDateExpr + ") AS max_date, COUNT(*)::int AS total FROM vat_backup_tax_invoice"),
      ]);
      return res.json({ by_source: bySource.rows, by_status: byStatus.rows, by_bu: byBu.rows, min_date: range.rows[0].min_date, max_date: range.rows[0].max_date, total: range.rows[0].total });
    }

    const conds = [];
    const vals = [];
    const add = (sql, v) => { vals.push(v); conds.push(sql.replace("?", "$" + vals.length)); };
    if (body.source_type) add("COALESCE(source_type, '') = ?", String(body.source_type) === "__blank__" ? "" : String(body.source_type));
    if (body.status) add("COALESCE(status, '') = ?", String(body.status) === "__blank__" ? "" : String(body.status));
    if (body.bu) add("bu = ?", String(body.bu));
    if (body.date_from) add(docDateExpr + " >= ?::date", String(body.date_from));
    if (body.date_to) add(docDateExpr + " <= ?::date", String(body.date_to));
    if (body.older_than_months !== undefined && body.older_than_months !== null && body.older_than_months !== "") {
      const months = Number(body.older_than_months);
      if (!Number.isInteger(months) || months < 1 || months > 120) {
        return res.status(400).json({ error: "older_than_months ต้องเป็นจำนวนเต็ม 1-120" });
      }
      conds.push(docDateExpr + " < (CURRENT_DATE - (" + months + " * INTERVAL '1 month'))::date");
    }
    if (conds.length === 0 && body.all !== true) {
      return res.status(400).json({ error: "ไม่ได้ระบุเงื่อนไข -- ถ้าต้องการล้างทั้งหมดต้องส่ง all=true" });
    }
    const where = conds.length ? "WHERE " + conds.join(" AND ") : "";

    const cnt = await pool.query("SELECT COUNT(*)::int AS n FROM vat_backup_tax_invoice " + where, vals);
    const count = cnt.rows[0].n;
    if (action === "preview") {
      // MARKER_PURGE_TAX_INVOICE_PREVIEW_SAMPLE_V1 -- ขอตัวอย่างแถวจริงที่จะลบ (ไม่ใช่แค่ตัวเลข) ให้ User เช็คก่อนกดลบจริง
      const sampleSql = "SELECT business_name, bu, bu_tax_id, bu_branch, supplier_name, tax_id_supplier, branch_supplier, " +
        docDateExpr + " AS doc_date, tax_invoice_number, gross_value, vat_value, total_value, status, source_type " +
        "FROM vat_backup_tax_invoice " + where + " ORDER BY " + docDateExpr + " DESC NULLS LAST LIMIT 15";
      const sample = await pool.query(sampleSql, vals);
      return res.json({ count, sample: sample.rows });
    }
    if (action !== "delete") {
      return res.status(400).json({ error: "action ไม่ถูกต้อง" });
    }
    if (Number(body.expected_count) !== count) {
      return res.status(409).json({ error: "จำนวนที่จะลบไม่ตรงกับที่ Preview ไว้ (ข้อมูลมีการเปลี่ยนแปลง) กรุณา Preview ใหม่", count });
    }
    const del = await pool.query("DELETE FROM vat_backup_tax_invoice " + where, vals);
    const filterDesc = JSON.stringify({ source_type: body.source_type || null, status: body.status || null, bu: body.bu || null, date_from: body.date_from || null, date_to: body.date_to || null, older_than_months: body.older_than_months || null, all: body.all === true });
    pool.query(
      "INSERT INTO activity_log (username, user_email, action, module, created_at) VALUES ($1, $2, $3, 'VAT_TAX_INVOICE', NOW())",
      [req.user?.username || null, req.user?.email || null, "PURGE_TAX_INVOICE deleted=" + del.rowCount + " filter=" + filterDesc]
    ).catch((e) => console.error("[purge tax invoice] activity_log error:", e.message));
    return res.json({ deleted: del.rowCount });
  } catch (err) {
    console.error("vat_backup_tax_invoice purge error:", err);
    res.status(500).json({ error: "Internal server error", detail: err.message });
  }
});
// MARKER_APP_SYNC_DRAFT_STATUS_FN_V1 -- แยก Logic Sync สถานะ Report <-> ตารางที่ผูกอยู่ (Popvat Draft / Note ฯลฯ) เป็นฟังก์ชัน ใช้ร่วมกันระหว่าง Route sync_draft_status (runner=pool) กับ replace_bu (runner=client ใน Transaction เดียวกัน)
async function syncDraftStatusForBu(runner, bu) {
    const toDraft = await runner.query(
      `UPDATE vat_watchlist_report r
       SET status = 'draft'
       FROM vat_upload_popvatdraft p
       WHERE r.bu = p.bu
         AND r.invoice_ref = p.original_invoice_number
         AND p.status = 'draft'
         AND (p.supplier_name IS NULL OR btrim(p.supplier_name) = '' OR left(btrim(COALESCE(r.vendor_name, '')), length(btrim(p.supplier_name))) = btrim(p.supplier_name) OR left(btrim(p.supplier_name), length(btrim(COALESCE(r.vendor_name, '')))) = btrim(COALESCE(r.vendor_name, ''))) -- MARKER_APP_SYNC_DRAFT_MATCH_SUPPLIER_V1 -- ต้อง Match BU + Invoice Ref + Supplier (ชื่อผู้ค้า ขึ้นต้นตรงกันได้ รองรับชื่อที่เคยมีข้อความ Total ต่อท้าย) ไม่ใช่แค่ Invoice Ref (Draft เก่าที่ supplier_name ว่างยังใช้ Invoice Ref อย่างเดียวเหมือนเดิม)
         AND r.status NOT IN ('draft', 'fu-draft', 'type_a', 'type_b', 'type_f') -- MARKER_APP_TYPE_ABF_STATUS_V1 / MARKER_APP_SYNC_FU_DRAFT_V1 -- fu-draft (Over Period) ห้ามถูกเปลี่ยนเป็น draft
         AND r.bu = $1
       RETURNING r.id`,
      [bu]
    );
    // MARKER_APP_SYNC_FU_DRAFT_V2 -- คู่ขนานกับ toDraft: Popvat Draft ที่เป็น fu-draft (Over Period) -> Report ต้องเป็น fu-draft (ไม่ทับแถวที่เป็น draft/type_a/b/f อยู่แล้ว)
    const toFuDraft = await runner.query(
      `UPDATE vat_watchlist_report r
       SET status = 'fu-draft'
       FROM vat_upload_popvatdraft p
       WHERE r.bu = p.bu
         AND r.invoice_ref = p.original_invoice_number
         AND p.status = 'fu-draft'
         AND (p.supplier_name IS NULL OR btrim(p.supplier_name) = '' OR left(btrim(COALESCE(r.vendor_name, '')), length(btrim(p.supplier_name))) = btrim(p.supplier_name) OR left(btrim(p.supplier_name), length(btrim(COALESCE(r.vendor_name, '')))) = btrim(COALESCE(r.vendor_name, '')))
         AND r.status NOT IN ('draft', 'fu-draft', 'type_a', 'type_b', 'type_f')
         AND r.bu = $1
       RETURNING r.id`,
      [bu]
    );
    const toPending = await runner.query(
      `UPDATE vat_watchlist_report r
       SET status = 'pending'
       WHERE r.status IN ('draft', 'fu-draft') -- MARKER_APP_SYNC_FU_DRAFT_V1 -- รวม fu-draft (Over Period) ให้คืนเป็น pending เมื่อไม่มี Popvat Draft รองรับ
         AND r.bu = $1
         AND NOT EXISTS (
           SELECT 1 FROM vat_upload_popvatdraft p
           WHERE p.bu = r.bu AND p.original_invoice_number = r.invoice_ref
             AND (p.supplier_name IS NULL OR btrim(p.supplier_name) = '' OR left(btrim(COALESCE(r.vendor_name, '')), length(btrim(p.supplier_name))) = btrim(p.supplier_name) OR left(btrim(p.supplier_name), length(btrim(COALESCE(r.vendor_name, '')))) = btrim(COALESCE(r.vendor_name, ''))) -- MARKER_APP_SYNC_DRAFT_MATCH_SUPPLIER_V1
             AND p.status IN ('draft', 'fu-draft', 'exported', 'pv-backup') -- MARKER_APP_SYNC_DRAFT_KEEP_EXPORTED_V1 / MARKER_APP_SYNC_FU_DRAFT_V1 -- Generate File แล้ว (exported/pv-backup) ห้ามย้อนกลับเป็น pending
         )
       RETURNING r.id`,
      [bu]
    );
    // MARKER_APP_SYNC_AGING_ACCEPT_CONDITION_V1
    // -- Note Accept with Condition -> Aging = 'Accept' ทันที (ทิศทางเดียว Note -> Report เท่านั้น) --
    const toAccept = await runner.query(
      `UPDATE vat_watchlist_report r
       SET aging_months = NULL, aging_label = 'Accept'
       FROM vat_watchlist_notes n
       WHERE r.bu = n.bu
         AND r.invoice_ref = n.invoice_ref
         AND r.supplier_code = n.supplier_code
         AND n.status = 'accept_with_condition'
         AND r.aging_label IS DISTINCT FROM 'Accept' -- MARKER_APP_SYNC_ACCEPT_NULL_SAFE_V1 -- เดิม != 'Accept' ข้ามแถวที่ aging_label เป็น NULL (NULL != x = NULL) ทำให้ Note ของใบที่ไม่มีวันชำระเงินไม่ถูกเปลี่ยนเป็น Accept
         AND r.status NOT IN ('type_a', 'type_b', 'type_f') -- MARKER_APP_TYPE_ABF_STATUS_V1
         AND r.bu = $1
       RETURNING r.id`,
      [bu]
    );
    return { to_draft: toDraft.rowCount, to_fu_draft: toFuDraft.rowCount, to_pending: toPending.rowCount, to_accept: toAccept.rowCount };
}
// MARKER_APP_VAT_WATCHLIST_SYNC_DRAFT_STATUS_V1
// -- POST /api/vat_watchlist_report/sync_draft_status -- Sync สถานะ Report <-> Popvat Draft (Bidirectional) --
// -- ต้องอยู่ก่อน Generic Mount เหมือน replace_bu ด้านบน --
app.post("/api/vat_watchlist_report/sync_draft_status", checkPermission("vat_watchlist_report", "write"), async (req, res) => {
  const { bu } = req.body || {};
  if (!bu) {
    return res.status(400).json({ error: "bu is required" });
  }
  try {
    const synced = await syncDraftStatusForBu(pool, bu);
    res.json({ success: true, ...synced });
  } catch (err) {
    console.error("vat_watchlist_report sync_draft_status error:", err);
    res.status(500).json({ error: "Internal server error", detail: err.message });
  }
});
// MARKER_APP_OLDINCOMPLETEREF_GET_LIST_V1 -- GET /api/vat_watchlist_old_incomplete_ref (อ่านอย่างเดียว) -- หน้า Check/Upload Incomplete เรียกใช้ตรวจ Exemption ของ Note ที่ผูก old_ref_check_no (เดิมได้ 404 -> ได้ List ว่าง -> Note ถูก Unmatch ผิด)
// -- ใช้ Route เฉพาะ ไม่ผ่าน createTableRouter กัน Backend ล้มตอนเริ่มทำงานถ้าตารางไม่อยู่ใน tablePermissions --
app.get("/api/vat_watchlist_old_incomplete_ref", checkPermission("vat_watchlist_report", "read"), async (req, res) => {
  try {
    const r = await pool.query("SELECT bu, invoice_ref, supplier_code, exp_amount, exp_vat, check_no, payment_date_old FROM vat_watchlist_old_incomplete_ref");
    res.json(r.rows);
  } catch (err) {
    console.error("vat_watchlist_old_incomplete_ref GET error:", err);
    res.status(500).json({ error: "Internal server error", detail: err.message });
  }
});
app.use("/api/vat_watchlist_report", createTableRouter("vat_watchlist_report")); // MARKER_APP_MOUNT_VAT_WATCHLIST_REPORT_V1
app.use("/api/vat_incomplete_column_config", createTableRouter("vat_incomplete_column_config")); // MARKER_APP_MOUNT_VAT_INCOMPLETE_COLUMN_CONFIG_V1
app.use("/api/vat_watchlist_bu_group_range", createTableRouter("vat_watchlist_bu_group_range")); // MARKER_APP_MOUNT_VAT_WATCHLIST_BU_GROUP_RANGE_V1
app.use("/api/vat_watchlist_related_person", createTableRouter("vat_watchlist_related_person")); // MARKER_APP_MOUNT_VAT_WATCHLIST_RELATED_PERSON_V1
app.use("/api/vat_mail_config", createTableRouter("vat_mail_config")); // MARKER_APP_MOUNT_VAT_MAIL_CONFIG_V1
app.use("/api/vat_mail_draft", createTableRouter("vat_mail_draft")); // MARKER_APP_MOUNT_VAT_MAIL_DRAFT_V1
app.use("/api/vat-mail-export", vatMailExportRouter); // MARKER_APP_MOUNT_VAT_MAIL_EXPORT_V1
app.use("/api/vat_watchlist_notes", createTableRouter("vat_watchlist_notes")); // MARKER_APP_MOUNT_VAT_WATCHLIST_NOTES_V1
app.use("/api/vat_incomplete_export_templates", createTableRouter("vat_incomplete_export_templates")); // MARKER_APP_MOUNT_VAT_INCOMPLETE_EXPORT_TEMPLATES_V1
app.use("/api/vat_upload_popvatdraft", createTableRouter("vat_upload_popvatdraft")); // MARKER_APP_MOUNT_VAT_UPLOAD_POPVATDRAFT_V1
app.use("/api/vat_backup_tax_invoice", createTableRouter("vat_backup_tax_invoice")); // MARKER_APP_MOUNT_VAT_BACKUP_TAX_INVOICE_V1
app.use("/api/vat_simpleinputdraft", createTableRouter("vat_simpleinputdraft")); // MARKER_APP_MOUNT_VAT_SIMPLEINPUT_ADI_DRAFT_V1
app.use("/api/ie_simplevatdraft", createTableRouter("ie_simplevatdraft")); // MARKER_APP_MOUNT_IE_SIMPLEVATDRAFT_V1 -- IE Invoice Detail > Tab "Simple" (Sub-row Real Vendor Add -> Simple)
app.use("/api/vat_adi_transferdraft", createTableRouter("vat_adi_transferdraft")); // MARKER_APP_MOUNT_VAT_SIMPLEINPUT_ADI_DRAFT_V1
app.use("/api/vat_watchlist_round_state", createTableRouter("vat_watchlist_round_state")); // MARKER_APP_MOUNT_VAT_WATCHLIST_ROUND_STATE_V1 -- Round-based Active BU Update Tracking (Donut + Confirm ปิดรอบ)
app.use("/api/vat_waiting_for_claim", createTableRouter("vat_waiting_for_claim")); // MARKER_APP_MOUNT_VAT_WAITING_FOR_CLAIM_V1 -- VAT Controller > Backup > Transaction, Tab 4 (Backup_Report Input Tax-Waiting for Claim)
app.use("/api/vat_reconcile_input_summary", createTableRouter("vat_reconcile_input_summary")); // MARKER_APP_MOUNT_VAT_RECONCILE_INPUT_SUMMARY_V1 -- VAT Input Rec. Dashboard > Quick Preview Popup > Inline Edit (Excel Grid)
app.use("/api/email_templates",     createTableRouter("email_templates"));
// MARKER_APP_MOUNT_VAT_SUMMARY_DASHBOARD_V1 -- VAT Watchlist Dashboard (vat_summary_schema.sql)
app.use("/api/vat_summary_live",            createTableRouter("vat_summary_live"));
app.use("/api/vat_summary_live_dashboard",  createTableRouter("vat_summary_live_dashboard"));
app.use("/api/vat_summary_frozen",          createTableRouter("vat_summary_frozen"));
app.use("/api/vat_summary_frozen_dashboard", createTableRouter("vat_summary_frozen_dashboard"));

// MARKER_APP_VAT_FREEZE_API_V1 -- หน้า Freeze: สถานะต่อ BU / สั่ง Freeze Final / ประวัติ
//   กฎ: งวดเปิด = Draft ตาม Live อัตโนมัติ (DB: fn_freeze_vat_sync_draft เรียกจาก fn_recompute_vat_summary_for_bu) | ปิด Period = Final (fn_freeze_vat_finalize)
//   หลังปิด: <=20 วัน grace, 21-30 วัน confirm, >30 วัน locked (fn_vat_freeze_window)
// MARKER_APP_VAT_FREEZE_OWNER_ONLY_V15 -- หน้า Freeze (status/history/run) เข้าได้เฉพาะ Owner (late_update ที่หน้าอัปโหลดเรียกใช้ ไม่ผูกกับหน้านี้ จึงไม่จำกัด)
const requireOwnerFreeze = (req, res, next) => (String(req.user?.appRole || "").toLowerCase() === "owner" ? next() : res.status(403).json({ error: "เฉพาะ Owner เท่านั้น" }));
app.get("/api/vat_freeze/status", requireOwnerFreeze, checkPermission("vat_summary_frozen", "read"), async (req, res) => {
  try {
    const pr = await pool.query(`SELECT period_month FROM (SELECT period_month FROM vat_summary_live UNION SELECT period_month FROM vat_summary_frozen) x WHERE period_month IS NOT NULL ORDER BY 1 DESC`);
    const periods = pr.rows.map((r) => r.period_month);
    const period = String(req.query.period || periods[0] || "");
    if (!period) return res.json({ ok: true, periods, period: null, window: null, rows: [] });
    const win = await pool.query("SELECT fn_vat_freeze_window($1) AS w", [period]);
    const { rows } = await pool.query(
      `WITH live AS (
         SELECT bu, count(*)::int AS n, COALESCE(sum(exp_vat),0) AS ev, COALESCE(sum(avg_vat),0) AS av, COALESCE(sum(invoice_count),0)::int AS ic,
                COALESCE(sum(exp_vat) FILTER (WHERE aging_risk = 'Expired'),0) AS te
         FROM vat_summary_live WHERE period_month = $1 GROUP BY bu),
       fz AS (
         SELECT bu, freeze_version, max(freeze_status) AS freeze_status, max(frozen_at) AS frozen_at, max(frozen_by) AS frozen_by, max(trigger_type) AS trigger_type,
                count(*)::int AS n, COALESCE(sum(exp_vat),0) AS ev, COALESCE(sum(avg_vat),0) AS av, COALESCE(sum(invoice_count),0)::int AS ic,
                COALESCE(sum(exp_vat) FILTER (WHERE aging_risk = 'Expired'),0) AS te
         FROM vat_summary_frozen WHERE period_month = $1 GROUP BY bu, freeze_version),
       fl AS (SELECT DISTINCT ON (bu) * FROM fz ORDER BY bu, freeze_version DESC)
       SELECT COALESCE(l.bu, f.bu) AS bu,
              l.te AS live_total_expired, f.te AS frozen_total_expired, f.freeze_version, f.freeze_status, f.frozen_at, f.frozen_by, f.trigger_type,
              CASE WHEN f.bu IS NULL THEN 'none'
                   WHEN l.bu IS NULL THEN 'frozen_only'
                   WHEN f.n = l.n AND abs(f.ev - l.ev) < 0.005 AND abs(f.av - l.av) < 0.005 AND f.ic = l.ic THEN 'synced'
                   ELSE 'diff' END AS sync_state
       FROM live l FULL JOIN fl f ON f.bu = l.bu
       ORDER BY 1`,
      [period]
    );
    res.json({ ok: true, periods, period, window: win.rows[0].w, rows });
  } catch (err) {
    console.error("GET /api/vat_freeze/status error:", err.message);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/api/vat_freeze/history", requireOwnerFreeze, checkPermission("vat_summary_frozen", "read"), async (req, res) => {
  try {
    const { period, bu } = req.query;
    if (!period) return res.status(400).json({ error: "period is required" });
    const params = [String(period)];
    let sql = "SELECT id, period_month, bu, freeze_version, trigger_type, frozen_by, frozen_at, row_count, total_exp_vat, total_expired, unrealized_in_expired, note FROM vat_freeze_log WHERE period_month = $1";
    if (bu) { params.push(String(bu)); sql += " AND bu = $2"; }
    sql += " ORDER BY frozen_at DESC LIMIT 500";
    const { rows } = await pool.query(sql, params);
    res.json({ ok: true, rows });
  } catch (err) {
    console.error("GET /api/vat_freeze/history error:", err.message);
    res.status(500).json({ error: "Internal server error" });
  }
});

// POST /api/vat_freeze/late_update  body: { as_of_month:'YYYY-MM', bus:[...], rows:[...], confirm?:boolean }
//   ไฟล์ Incomplete ที่ As-Of เป็นเดือนที่ปิด Period แล้ว: ไม่เข้า vat_watchlist_report เลย -- พักไว้ที่ vat_watchlist_late_stage
//   -> fn_freeze_vat_late_update คำนวณ Freeze Final เวอร์ชันใหม่ของเดือนนั้น แล้วลบข้อมูลที่พักทิ้ง (พลาด = ลบให้ด้วย)
//   กฎเวลา (DB: fn_vat_freeze_window): <=20 วัน อัปเดตได้ | 21-30 วัน ต้อง confirm | >30 วัน 409 ห้ามทุกกรณี | งวดยังเปิด 409
app.post("/api/vat_freeze/late_update", checkPermission("vat_watchlist_report", "write"), async (req, res) => { // MARKER_APP_VAT_FREEZE_LATE_UPDATE_V1
  const { as_of_month, bus, rows, confirm } = req.body || {};
  if (!/^\d{4}-\d{2}$/.test(String(as_of_month || ""))) return res.status(400).json({ error: "as_of_month ต้องเป็นรูปแบบ YYYY-MM" });
  if (!Array.isArray(bus) || bus.length === 0) return res.status(400).json({ error: "bus (array) is required" });
  if (!Array.isArray(rows)) return res.status(400).json({ error: "rows (array) is required" });
  const user = (req.user && req.user.email) || "system";
  const client = await pool.connect();
  try {
    const winQ = await client.query("SELECT fn_vat_freeze_window($1) AS w", [as_of_month]);
    const win = winQ.rows[0].w;
    if (win.state === "open") return res.status(409).json({ error: `เดือน ${as_of_month} ยังเป็น Period ที่เปิดอยู่ ให้อัปโหลดเข้า Report ตามปกติ`, code: "PERIOD_OPEN", window: win });
    if (win.state === "locked") return res.status(409).json({ error: `เดือน ${as_of_month} ถูกล็อกแล้ว (${win.reason || `ปิดมาแล้ว ${win.days_since_close} วัน`}) ห้ามอัปเดต Freeze ทุกกรณี ต้องแก้ด้วยวิธีอื่น`, code: "LOCKED", window: win });
    if (win.state !== "grace" && win.state !== "confirm") return res.status(409).json({ error: "ไม่ทราบสถานะ Period", window: win });
    if (win.state === "confirm" && !confirm) return res.json({ ok: true, needs_confirm: true, window: win });

    const buSet = new Set(bus);
    const stageRows = rows.filter((r) => r && buSet.has(r.bu));
    await client.query("BEGIN");
    await client.query("SET LOCAL lock_timeout = '20s'");
    await client.query("DELETE FROM vat_watchlist_late_stage WHERE bu = ANY($1::text[]) AND as_of_month = $2", [bus, as_of_month]);
    const cols = [...VAT_REPORT_INSERT_COLUMNS, "as_of_month", "staged_by"];
    const CHUNK = 1000;
    for (let i = 0; i < stageRows.length; i += CHUNK) {
      const chunk = stageRows.slice(i, i + CHUNK);
      const values = [];
      const ph = chunk.map((row, ri) => {
        const base = ri * cols.length;
        cols.forEach((c) => values.push(c === "as_of_month" ? as_of_month : c === "staged_by" ? user : (row[c] === undefined ? null : row[c])));
        return `(${cols.map((_, j) => `$${base + j + 1}`).join(", ")})`;
      }).join(", ");
      await client.query(`INSERT INTO vat_watchlist_late_stage (${cols.join(", ")}) VALUES ${ph}`, values);
    }
    const results = [];
    for (const b of bus) {
      try {
        await client.query("SAVEPOINT late_freeze_sp");
        const q = await client.query("SELECT fn_freeze_vat_late_update($1, $2, $3, 'late-update', $4) AS r", [as_of_month, b, user, !!confirm]);
        results.push({ bu: b, ...q.rows[0].r });
        await client.query("RELEASE SAVEPOINT late_freeze_sp");
      } catch (e) {
        try { await client.query("ROLLBACK TO SAVEPOINT late_freeze_sp"); } catch (e2) { /* ignore */ }
        console.error("[late_update] freeze error:", b, e.message);
        results.push({ bu: b, action: "error", error: e.message });
      }
    }
    await client.query("DELETE FROM vat_watchlist_late_stage WHERE bu = ANY($1::text[]) AND as_of_month = $2", [bus, as_of_month]); // ลบข้อมูลที่พักทิ้งเสมอ (รวม BU ที่พลาด)
    await client.query("COMMIT");
    const count = (a) => results.filter((x) => x.action === a).length;
    res.json({ ok: true, as_of_month, window: win, total: results.length, frozen: count("frozen"), skipped: count("skipped_no_rows"), errors: count("error"), results });
  } catch (err) {
    try { await client.query("ROLLBACK"); } catch (e) { /* ignore */ }
    console.error("POST /api/vat_freeze/late_update error:", err.message);
    res.status(500).json({ error: "Internal server error", detail: err.message });
  } finally {
    client.release();
  }
});

// POST /api/vat_freeze/run  body: { period, bus?: string[], force?: boolean, confirm?: boolean }
//   Freeze Final ด้วยมือ (ปกติระบบทำเองตอนปิด Period) | bus ว่าง = ทุก BU ของงวดนั้น | force = ทำใหม่แม้ยอดเท่าเดิม | confirm = ยืนยันกรณี 21-30 วันหลังปิด
//   DB บังคับกฎให้: locked (>30 วัน) ปฏิเสธทุกกรณี และ Freeze ได้เฉพาะงวดปัจจุบันของ BU
app.post("/api/vat_freeze/run", requireOwnerFreeze, checkPermission("vat_watchlist_report", "write"), async (req, res) => {
  try {
    const { period, bus, force, confirm } = req.body || {};
    if (!period) return res.status(400).json({ error: "period is required" });
    let targets = Array.isArray(bus) ? bus.filter(Boolean) : [];
    if (targets.length === 0) {
      const t = await pool.query("SELECT DISTINCT bu FROM vat_summary_live WHERE period_month = $1 ORDER BY bu", [String(period)]);
      targets = t.rows.map((r) => r.bu);
    }
    const user = (req.user && req.user.email) || "system";
    const results = [];
    for (const b of targets) {
      try {
        const q = await pool.query("SELECT fn_freeze_vat_finalize($1, $2, $3, 'manual', $4, $5) AS r", [String(period), b, user, !!force, !!confirm]);
        results.push({ bu: b, ...q.rows[0].r });
      } catch (e) {
        results.push({ bu: b, action: "error", error: e.message });
      }
    }
    const count = (a) => results.filter((x) => x.action === a).length;
    res.json({ ok: true, period, total: results.length, frozen: count("frozen"), unchanged: count("unchanged"), locked: count("locked"), needs_confirm: count("needs_confirm"), errors: count("error"), results });
  } catch (err) {
    console.error("POST /api/vat_freeze/run error:", err.message);
    res.status(500).json({ error: "Internal server error" });
  }
});

// MARKER_APP_VAT_FREEZE_REFRESH_BU_V1 -- POST /api/vat_freeze/refresh_bu  body: { bu }
//   Note/Check Return เปลี่ยน Unrealized (Accept) -> Freeze ซ้ำเฉพาะ BU นั้น ให้ยอด Unrealized ใน Freeze เป็นปัจจุบันที่สุด
//   ทำเฉพาะงวดล่าสุดของ BU ที่ Freeze เป็น "final" แล้วเท่านั้น (งวดที่ยังเปิด = Draft ตาม Live เองอยู่แล้ว ห้าม Final ก่อนเวลา)
//   กฎเวลา (<=20 วัน / 21-30 ต้องยืนยัน / >30 ล็อก) ให้ fn_freeze_vat_finalize ตัดสิน -- ไม่ส่ง confirm จึงไม่ Freeze ทับช่วง 21-30 วันเอง
//   ไม่จำกัดเฉพาะ Owner (เรียกจากหน้า Note/Check Return ของผู้ใช้ทั่วไป) แต่ต้องมีสิทธิ์เขียน vat_watchlist_report
app.post("/api/vat_freeze/refresh_bu", checkPermission("vat_watchlist_report", "write"), async (req, res) => {
  try {
    const bu = String((req.body && req.body.bu) || "").trim();
    if (!bu) return res.status(400).json({ error: "bu is required" });
    const pr = await pool.query("SELECT max(period_month) AS p FROM vat_summary_live WHERE bu = $1", [bu]);
    const period = pr.rows[0] && pr.rows[0].p;
    if (!period) return res.json({ ok: true, bu, action: "skipped_no_period" });
    const fz = await pool.query(
      "SELECT freeze_status FROM vat_summary_frozen WHERE bu = $1 AND period_month = $2 ORDER BY freeze_version DESC LIMIT 1",
      [bu, String(period)]
    );
    const user = (req.user && req.user.email) || "system";
    // MARKER_APP_VAT_FREEZE_REFRESH_BU_PREV_V1 -- งวดที่ปิดล่าสุด (เดือนก่อนงวดปัจจุบัน) ที่ Freeze เป็น Final แล้ว:
    //   Note ที่บันทึกหลังปิด -> ย้าย Realized -> Unrealized ใน Final งวดนั้น (fn_vat_restate_unrealized; กรอบ 20/30 วันตัดสินใน DB)
    const pm = /^(\d{4})-(\d{2})$/.exec(String(period));
    let previous = null;
    if (pm) {
      const d = new Date(Date.UTC(Number(pm[1]), Number(pm[2]) - 2, 1));
      const prevPeriod = d.getUTCFullYear() + "-" + String(d.getUTCMonth() + 1).padStart(2, "0");
      try {
        const rq = await pool.query("SELECT fn_vat_restate_unrealized($1, $2, $3, false) AS r", [prevPeriod, bu, user]);
        previous = rq.rows[0].r;
      } catch (e2) {
        console.error("fn_vat_restate_unrealized error:", e2.message);
        previous = { action: "error", period: prevPeriod };
      }
    }
    if (!fz.rows[0] || String(fz.rows[0].freeze_status).toLowerCase() !== "final") {
      return res.json({ ok: true, bu, period, action: "skipped_not_final", previous });
    }
    const q = await pool.query("SELECT fn_freeze_vat_finalize($1, $2, $3, 'manual', true, false) AS r", [String(period), bu, user]);
    res.json({ ok: true, bu, period, ...q.rows[0].r, previous });
  } catch (err) {
    console.error("POST /api/vat_freeze/refresh_bu error:", err.message);
    res.status(500).json({ error: "Internal server error" });
  }
});

// MARKER_APP_VAT_WATCHLIST_VENDOR_NAME_JUNK_CLEAN_V1 — ตามไฟล์ตัวอย่างที่พี่ส่งมา (a25471a1 /
// acc870aa) พบว่าเข้าใจผิดมาตลอด: ปัญหาไม่ใช่ "มีบาง Row เป็น Row สรุปยอด/Row คั่นปนมาทั้ง Row"
// (ที่ Filter เดิมตัดทิ้งทั้ง Row) แต่คือ vendor_name ของแทบทุก Row จริง (Invoice จริง มี invoice_ref/
// exp_amount ปกติ) มี "หาง" เป็น Footer ของรายงานเก่า (เส้นประ, "Total Group Branch", "รวมทั้งสิ้น",
// "====", "ตั้งแต่วันที่...", "หน้า: x/y") ต่อท้ายชื่อ Vendor จริงมาด้วย เช่น
// "บางนาคอมเพล็กซ์ บจก. (สาขาที่00001) -------------------- ... Total Group Branch : ..."
// ชื่อ Vendor จริงคือแค่ "บางนาคอมเพล็กซ์ บจก. (สาขาที่00001)" ส่วนที่เหลือเป็นขยะที่หลุดติดมาตอน
// Parse จาก PDF/Report ต้นทาง -- Filter แบบเดิม (ตัดทั้ง Row ถ้า vendor_name มีคำว่า "Total Group
// Branch" หรือมีเส้นประ) จะตัด Invoice จริงทิ้งเกือบหมดทั้งตาราง ผิดทางแต่แรก -- แก้ใหม่ให้ "ตัดหาง"
// ออกจาก vendor_name แทนการตัดทั้ง Row ทิ้ง (เก็บ Invoice ไว้ แค่ทำความสะอาด Field)
function cleanJunkVendorNameSql(alias = "w") {
  // ตัดตั้งแต่เส้นประยาว (4 ตัวขึ้นไป) แรกที่เจอไปจนจบ String แล้ว Trim ช่องว่างท้ายที่เหลือ
  return `(CASE WHEN ${alias}.vendor_name ~ '-{4,}'
    THEN TRIM(regexp_replace(${alias}.vendor_name, '-{4,}.*$', ''))
    ELSE ${alias}.vendor_name END)`;
}
// ใช้ฝั่ง JS (ตอน Insert ข้อมูลใหม่เข้า vat_watchlist_report) -- Logic เดียวกับ SQL ด้านบนเป๊ะๆ
function cleanJunkVendorNameJs(vendorName) {
  if (typeof vendorName !== "string") return vendorName;
  const m = vendorName.match(/^(.*?)-{4,}/);
  if (!m) return vendorName;
  return m[1].trim();
}

// ── GET /api/vat_watchlist_detail?bu=XXX&bucket=realized|unrealized&bus_type=YYY ──
// MARKER_APP_MOUNT_VAT_WATCHLIST_DETAIL_V1 — ดึงรายการ Invoice ระดับละเอียดจาก vat_watchlist_report
// สำหรับ Popup "Expired Detail" ของ VatDashboard.js (เดิมเขียนไว้ใน routes/vatSummaryRoutes.js
// แต่ไฟล์นั้นไม่เคย import เข้า app.js จริง — ย้ายมา Mount ตรงนี้ให้ตรงกับ Pattern /api/... ของไฟล์นี้)
//   bu          → optional, ไม่ใส่ = เอาทุก BU (ใช้สำหรับสรุปยอดตาม Reason ข้ามทุก BU)
//   bucket=realized   → Expired แบบปกติ ที่ไม่ใช่ Accept with Condition
//   bucket=unrealized → Accept with Condition (aging_label='Accept') ทุกใบ ไม่ว่า remark อะไรหรือว่าง
//     (Check Return / Check On Hand / Issue / Other) เพราะ "ไม่ว่าจะเป็นด้วยเหตุผลอะไรมันก็ต้องแสดงให้ได้"
//   ไม่ส่ง bucket → เอาทั้งหมดที่ Expired (ทั้ง Realized + Unrealized)
app.get("/api/vat_watchlist_detail", async (req, res) => {
  try {
    const { bu, bucket, bus_type } = req.query;
    const conditions = [`w.status = 'pending'`];
    const params = [];
    if (bu) {
      params.push(bu);
      conditions.push(`w.bu = $${params.length}`);
    }
    // MARKER_APP_VAT_WATCHLIST_DETAIL_UNREALIZED_ACCEPT_V1 -- Unrealized = Accept with Condition (aging_label='Accept')
    // ทุกใบ ไม่ว่า remark จะเป็น Check Return / Check On Hand / Issue / Other หรือว่าง (เดิมบังคับ remark ไม่ว่าง
    // ทำให้ Accept ที่ไม่มี remark หลุดไปเป็น Realized/ไม่แสดงเลย) / Realized = Expired ที่ไม่ใช่ Accept
    // MARKER_APP_VAT_WATCHLIST_DETAIL_ACCEPT_ACTUAL_AGING_V1 -- Accept ถูกล้าง aging_months เป็น NULL จึงคำนวณอายุจริงจาก payment_date
    // เทียบเดือนงวดของ BU (สูตรเดียวกับตอน Upload: ต่าง >= 7 เดือน = Expired) -- Accept ที่อายุยังไม่ถึง Expired (เช่น Aging 6) ยังไม่แสดงใน Expired Detail
    // จนกว่างวดจะเดินไปถึง Expired เพื่อให้ตรงกับยอด Total Expired ของตารางสรุป
    const acceptActualExpiredSql = `fn_vat_aging_month(w.payment_date, (fn_vat_effective_period_month(w.bu) || '-01')::date) = 'Expired'`;
    conditions.push(
      `(w.aging_label ILIKE '%expired%' OR (w.aging_label = 'Accept' AND ${acceptActualExpiredSql}) OR w.aging_months > 6)`
    );
    if (bucket === "realized") {
      conditions.push(`COALESCE(w.aging_label, '') <> 'Accept'`);
    } else if (bucket === "unrealized") {
      conditions.push(`w.aging_label = 'Accept'`);
    }
    if (bus_type) {
      params.push(bus_type);
      conditions.push(`COALESCE(NULLIF(w.bus_type, ''), 'OTH') = $${params.length}`);
    }
    // MARKER_APP_VAT_WATCHLIST_DETAIL_VENDOR_NAME_CLEAN_SAFETY_NET_V1 — Safety Net เผื่อมี Row เก่าที่
    // ยังไม่ผ่านการ Clean DB (ตาม SQL ที่ให้ไป Run ใน pgAdmin) หลุดมา -- Override vendor_name ด้วย
    // Version ที่ตัดหาง Junk แล้วตอน Query (SELECT w.*, cleaned AS vendor_name -- node-postgres สร้าง
    // Object จาก Column ตามลำดับ ชื่อซ้ำกัน Column หลังสุดจะทับ Column ก่อนหน้าเสมอ จึงใช้ Pattern นี้
    // Override Field ซ้ำชื่อกันได้โดยไม่ต้อง List Column ทั้งหมดทีละตัว)
    // MARKER_APP_VAT_WATCHLIST_DETAIL_SLIM_COLS_V1 -- ลดข้อมูลที่ดึง: เลือกเฉพาะ Column ที่ Dashboard ใช้จริง (แทน SELECT w.*)
    // เรียงตามลำดับ Column ในตารางเดิม (Frontend ใช้ลำดับ Key ของ Object จัดลำดับตาราง) -- vendor_name ตัดหาง Junk แล้วอยู่ตำแหน่งเดิม
    const { rows } = await pool.query(
      `SELECT w.doc_date, w.doc_no, w.site, w.pay_group, w.branch, w.tax_type, w.invoice_ref, w.supplier_code,
              ${cleanJunkVendorNameSql("w")} AS vendor_name,
              w.payment_date, w.check_date, w.check_no, w.receive_doc_date, w.receive_doc_no,
              w.exp_amount, w.exp_vat, w.avg_amount, w.avg_vat,
              w.bu, w.bus_type, w.aging_months, w.aging_label, w.remark,
              w.old_ref_check_no, w.old_ref_pay_date
       FROM vat_watchlist_report w WHERE ${conditions.join(" AND ")} ORDER BY w.exp_vat DESC NULLS LAST LIMIT 1000`,
      params
    );
    res.json(rows);
  } catch (err) {
    console.error("GET /api/vat_watchlist_detail error:", err);
    res.status(500).json({ error: "Failed to fetch vat_watchlist_detail" });
  }
});

// ── Reserve unique GRT/GRN number (ป้องกัน race condition + กันเลขซ้ำจริง) ──
// ── ล็อก row ด้วย transaction, บวกเลข, เช็คซ้ำกับข้อมูลจริงใน bucket_list, ────
// ── วนจนไม่ซ้ำ แล้วค่อย commit — ปลอดภัย 100% ไม่มีเลขถูกข้ามทิ้งแบบ block ──
app.post("/api/company_list/:id/reserve-unique-number", async (req, res) => {
  const { id } = req.params;
  const { field, prefix = '', bu = '', padLength = 4, semiUser = '', bootstrapField = '', checkPrefix = '' } = req.body;
  // MARKER_APP_ALLOW_OV_FIELDS_V1
  // MARKER_APP_ALLOW_SEMIUSER_FIELD_V1
  const allowedFields = ['ap_grt', 'ap_grn', 'ap_grt_ov', 'ap_grn_ov', 'batch_running', 'ap_grt_semiuser', 'ie_grt', 'ie_grn', 'ie_grt_ov', 'ie_grn_ov', 'ie_grt_prev', 'ie_grn_prev']; // MARKER_APP_RESERVE_UNIQUE_NUMBER_ALLOW_IE_FIELDS_V1 -- เพิ่ม field ของ IE (Column ยืนยันจาก pgAdmin แล้ว)
  if (!allowedFields.includes(field)) {
    return res.status(400).json({ error: "Invalid field. ???????? ap_grt, ap_grn ???? batch_running ????????" });
  }

  // -- batch_running: ??? Running ??? BU ?????? (Lazy Reset � ????????? Cron Job ???) --
  // -- ?????????????????? bucket_list ?????? GRT/GRN ??????????????????????????????? --
  if (field === 'batch_running') {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const { rows: lockedRows } = await client.query(
        `SELECT batch_running, batch_running_date::text AS batch_running_date_txt,
                (NOW() AT TIME ZONE 'Asia/Bangkok')::date::text AS today_bkk
           FROM company_list WHERE id = $1 FOR UPDATE`,
        [id]
      );
      if (!lockedRows[0]) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: "Not found" });
      }
      // MARKER_APP_BATCHRUNNING_BKK_UNIQUE_V1
      // -- แก้บั๊ก Batch Name ซ้ำ: เดิมตัดวันด้วย UTC (Reset ตอน 07:00 น. ไทย) แต่ชื่อ Batch ใช้วันที่เวลาไทย --
      // -- ตอนนี้ตัดวันด้วย Asia/Bangkok ให้ตรงกับชื่อ Batch + เช็คซ้ำกับ batch_list จริงก่อนคืนเลข --
      const todayStr = lockedRows[0].today_bkk; // YYYY-MM-DD (เวลาไทย)
      const lastDateStr = lockedRows[0].batch_running_date_txt
        ? String(lockedRows[0].batch_running_date_txt).slice(0, 10)
        : null;
      // ????????????????????????? ? Reset ???????? 0 ???? ???????? +1
      let running = (lastDateStr === todayStr) ? (parseInt(lockedRows[0].batch_running, 10) || 0) : 0;
      running += 1;
      // -- ข้ามเลขที่มีอยู่แล้วใน batch_list (Frontend ส่ง checkPrefix = "{Base}/{SystemPrefix}-" มาให้) --
      if (checkPrefix) {
        for (let guard = 0; guard < 1000; guard++) {
          const cand = `${checkPrefix}${prefix}${String(running).padStart(padLength, '0')}`;
          const { rows: dup } = await client.query(`SELECT 1 FROM batch_list WHERE batch_id = $1 LIMIT 1`, [cand]);
          if (!dup.length) break;
          running += 1;
        }
      }
      const formatted = `${prefix}${String(running).padStart(padLength, '0')}`;
      await client.query(
        `UPDATE company_list SET batch_running = $1, batch_running_date = $2 WHERE id = $3`,
        [running, todayStr, id]
      );
      await client.query('COMMIT');
      // MARKER_APP_GRTGRN_BROADCAST_V1
      // -- Broadcast Real-time � ????????????????????????? (BU ????????) ------
      // -- ??????????????????????? ????????? Submit ??????? Error ----------
      wsBroadcast('grt_grn_reserved', { id, field, bu, value: running });
      return res.json({ value: running, formatted });
    } catch (err) {
      await client.query('ROLLBACK').catch(() => {});
      console.error('reserve-unique-number (batch_running) error:', err.message);
      return res.status(500).json({ error: "Internal server error" });
    } finally {
      client.release();
    }
  }

  // MARKER_APP_SEMIAUTO_GRT_CHANNEL_RESERVE_V1
  // -- Semi-Auto GRT: reserve เลขจาก Channel รายคน (ap_grt_semiuser[semiUser]) --
  // -- แยกจากเลขกลาง (ap_grt) โดยสิ้นเชิง -- ไม่แยกตาม Override/Current Period --
  // -- (Channel เป็น Counter เดี่ยวต่อ User เท่านั้น ไม่มี ov/prev variant) -------
  if (field === 'ap_grt_semiuser') {
    if (!semiUser) {
      return res.status(400).json({ error: "Missing semiUser" });
    }
    // MARKER_APP_SEMIAUTO_GRT_BOOTSTRAP_WHITELIST_V1
    // -- Whitelist ชื่อ Column ที่จะใช้ Bootstrap กัน SQL Injection ผ่านชื่อ Column --
    const allowedBootstrapFields = ['ap_grt', 'ap_grt_prev', 'ap_grt_ov'];
    const bField = allowedBootstrapFields.includes(bootstrapField) ? bootstrapField : 'ap_grt';
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const { rows: lockedRows } = await client.query(
        `SELECT ap_grt_semiuser, "${bField}" AS bootstrap_val FROM company_list WHERE id = $1 FOR UPDATE`,
        [id]
      );
      if (!lockedRows[0]) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: "Not found" });
      }
      const channels = lockedRows[0].ap_grt_semiuser || {};
      // MARKER_APP_SEMIAUTO_GRT_BOOTSTRAP_LOGIC_V1
      // -- ถ้า Channel ของ User นี้ยังไม่เคยมีมาก่อน -- Bootstrap เริ่มนับจาก --
      // -- เลขกลาง (bField) แทนเริ่มจาก 0 ให้ตรงกับที่ Frontend โชว์ Fallback --
      const existingRunning = channels[semiUser]?.running_num;
      let running = (existingRunning !== undefined && existingRunning !== null && existingRunning !== '')
        ? (parseInt(existingRunning, 10) || 0)
        : (parseInt(lockedRows[0].bootstrap_val, 10) || 0);
      let formatted = '';
      let attempts = 0;
      const MAX_ATTEMPTS = 10000;
      while (attempts < MAX_ATTEMPTS) {
        running += 1;
        formatted = `${prefix}${String(running).padStart(padLength, '0')}`;
        const { rows: dupRows } = await client.query(
          `SELECT 1 FROM bucket_list WHERE bu = $1 AND form_data->>'grtNum' = $2 LIMIT 1`,
          [bu, formatted]
        );
        if (dupRows.length === 0) break;
        attempts += 1;
      }
      if (attempts >= MAX_ATTEMPTS) {
        await client.query('ROLLBACK');
        return res.status(500).json({ error: "หาเลขที่ไม่ซ้ำไม่สำเร็จ (พยายามครบจำนวนสูงสุดแล้ว)" });
      }
      channels[semiUser] = { running_num: String(running).padStart(padLength, '0'), updated_at: new Date().toISOString() };
      await client.query(`UPDATE company_list SET ap_grt_semiuser = $1 WHERE id = $2`, [JSON.stringify(channels), id]);
      await client.query('COMMIT');
      wsBroadcast('grt_grn_reserved', { id, field: 'ap_grt_semiuser', bu, value: running, semiUser });
      return res.json({ value: running, formatted });
    } catch (err) {
      await client.query('ROLLBACK').catch(() => {});
      console.error('reserve-unique-number (ap_grt_semiuser) error:', err.message);
      return res.status(500).json({ error: "Internal server error" });
    } finally {
      client.release();
    }
  }

  const jsonKey = field.includes('grt') ? 'grtNum' : 'grn'; // MARKER_APP_RESERVE_UNIQUE_NUMBER_ALLOW_IE_FIELDS_V1 -- generalize ให้รองรับทุก prefix (ap_/ie_/vat_) ไม่ hardcode เฉพาะ ap_grt
  const col = `"${field}"`;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows: lockedRows } = await client.query(
      `SELECT ${col} FROM company_list WHERE id = $1 FOR UPDATE`,
      [id]
    );
    if (!lockedRows[0]) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: "Not found" });
    }
    let running = parseInt(lockedRows[0][field], 10) || 0;
    let formatted = '';
    let attempts = 0;
    const MAX_ATTEMPTS = 10000;
    while (attempts < MAX_ATTEMPTS) {
      running += 1;
      formatted = `${prefix}${String(running).padStart(padLength, '0')}`;
      const { rows: dupRows } = await client.query(
        `SELECT 1 FROM bucket_list WHERE bu = $1 AND form_data->>'${jsonKey}' = $2 LIMIT 1`,
        [bu, formatted]
      );
      if (dupRows.length === 0) break;
      attempts += 1;
    }
    if (attempts >= MAX_ATTEMPTS) {
      await client.query('ROLLBACK');
      return res.status(500).json({ error: "?????????????????????????? (??????????????????????????)" });
    }
    await client.query(`UPDATE company_list SET ${col} = $1 WHERE id = $2`, [running, id]);
    await client.query('COMMIT');
    // -- Broadcast Real-time (?? Comment ????????????? batch_running branch) --
    wsBroadcast('grt_grn_reserved', { id, field, bu, value: running });
    res.json({ value: running, formatted });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    console.error('reserve-unique-number error:', err.message);
    res.status(500).json({ error: "Internal server error" });
  } finally {
    client.release();
  }
});

// MARKER_APP_SEMIAUTO_GRT_SET_ENDPOINT_V1
// -- POST /api/company_list/:id/set-semiauto-grt ------------------------
// -- Frontend ตัดสินใจเลข GRT มาเรียบร้อยแล้ว (จาก Running ของ User เอง) --
// -- Endpoint นี้แค่ "บันทึกเลขที่ตัดสินใจแล้ว" ลง Channel ไม่คำนวณ/Increment --
// -- เอง และไม่เช็คซ้ำใดๆ ทั้งสิ้น (Frontend รับผิดชอบความถูกต้องของเลข) -----
app.post("/api/company_list/:id/set-semiauto-grt", async (req, res) => {
  const { id } = req.params;
  const { semiUser = '', running_num = '' } = req.body;
  if (!semiUser) {
    return res.status(400).json({ error: "Missing semiUser" });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows: lockedRows } = await client.query(
      `SELECT ap_grt_semiuser FROM company_list WHERE id = $1 FOR UPDATE`,
      [id]
    );
    if (!lockedRows[0]) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: "Not found" });
    }
    const channels = lockedRows[0].ap_grt_semiuser || {};
    channels[semiUser] = { running_num: String(running_num), updated_at: new Date().toISOString() };
    await client.query(`UPDATE company_list SET ap_grt_semiuser = $1 WHERE id = $2`, [JSON.stringify(channels), id]);
    await client.query('COMMIT');
    wsBroadcast('grt_grn_reserved', { id, field: 'ap_grt_semiuser', bu: req.body.bu || '', value: parseInt(running_num, 10) || 0, semiUser });
    return res.json({ ok: true, semiUser, running_num: channels[semiUser].running_num });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    console.error('set-semiauto-grt error:', err.message);
    return res.status(500).json({ error: "Internal server error" });
  } finally {
    client.release();
  }
});
// -- PUT /api/user_roles/self/system_prefix � ??? Role ???? Prefix ???????????? --
// -- ??????????? Owner (??????? user_roles Write ??????????????? Owner) ????? --
// -- ??????? Preference ??????? ?????????????????? Role/Permission ?????? ------
// -- ??????? req.user (Login ????????) ?????????? Email ???? Update ???????????? --
app.put("/api/user_roles/self/system_prefix", async (req, res) => {
  try {
    const { system_prefix } = req.body;
    if (!system_prefix || typeof system_prefix !== "string" || !system_prefix.trim()) {
      return res.status(400).json({ error: "????????? system_prefix" });
    }
    const myEmail = String(req.user?.email || "").toLowerCase();
    if (!myEmail) {
      return res.status(401).json({ error: "??????????? User ??? Login" });
    }
    const { rows } = await pool.query(
      `UPDATE user_roles SET system_prefix = $1 WHERE LOWER(email) = $2 RETURNING id, username, email, system_prefix`,
      [system_prefix.trim().toUpperCase(), myEmail]
    );
    if (!rows[0]) {
      return res.status(404).json({ error: "????? User ???????????? user_roles" });
    }
    res.json({ ok: true, data: rows[0] });
  } catch (err) {
    console.error("PUT /api/user_roles/self/system_prefix error:", err.message);
    res.status(500).json({ error: "Internal server error" });
  }
});
app.use("/api/cpc_list",            createTableRouter("cpc_list"));
app.use("/api/itemcode_list",       createTableRouter("itemcode_list"));
app.use("/api/supplier_list",       createTableRouter("supplier_list"));
app.use("/api/account_cpc_rules",   createTableRouter("account_cpc_rules")); // MARKER_ACCOUNT_CPC_RULES_ROUTER_V1
app.use("/api/notice_list",         createTableRouter("notice_list"));
app.use("/api/sub_acc_list",        createTableRouter("sub_acc_list"));
app.use("/api/contract_list",       createTableRouter("contract_list"));
app.use("/api/vendor_category",     createTableRouter("vendor_category"));
app.use("/api/sm_code_list",        createTableRouter("sm_code_list"));
app.use("/api", itemMasterSearchRouter); // MARKER_APP_MOUNT_ITEM_MASTER_SEARCH_V1
app.use("/api", supplierSearchRouter); // MARKER_APP_MOUNT_SUPPLIER_SEARCH_V1
app.use("/api/user_roles",          createTableRouter("user_roles"));
// MARKER_APP_MOUNT_TAX_CLOSE_TABLES_V1 -- Timeline ปิดภาษี: อ่าน/เขียนผ่าน Generic Router
app.use("/api/tax_close_period",                createTableRouter("tax_close_period"));
app.use("/api/tax_close_bu_master",             createTableRouter("tax_close_bu_master"));
app.use("/api/tax_close_period_bu",             createTableRouter("tax_close_period_bu"));
app.use("/api/tax_close_task",                  createTableRouter("tax_close_task"));
app.use("/api/tax_close_task_log",              createTableRouter("tax_close_task_log"));
app.use("/api/tax_close_task_item",             createTableRouter("tax_close_task_item"));
app.use("/api/tax_close_bu_config",             createTableRouter("tax_close_bu_config", { idColumn: "bu_code" })); // MARKER_APP_TAXCLOSE_BU_CONFIG_IDCOLUMN_V1 -- ตารางนี้ไม่มี Column id (PK = bu_code+config_key) ถ้าไม่ระบุ idColumn Default ORDER BY "id" จะ Error 500
app.use("/api/timeline_watch",      createTableRouter("timeline_watch")); // MARKER_APP_MOUNT_TIMELINE_WATCH_V1 -- Timeline ปิดภาษี > Config BU > ดู Progress (1 แถวต่อ User)
app.use("/api/timeline_progress",   createTableRouter("timeline_progress")); // MARKER_APP_MOUNT_TIMELINE_PROGRESS_V1 -- Timeline ปิดภาษี: ความคืบหน้าต่อ Period + BU (JSONB)
app.use("/api/system_settings",     createTableRouter("system_settings", { idColumn: "key" }));
app.use("/api/Vendor_rule",         createTableRouter("Vendor_rule"));
// MARKER_IECODE_USAGE_TOUCH_ROUTER_V1 -- Mount ก่อน Generic Router เดิม (Route เฉพาะ /:id/touch ไม่ชนกับ Generic Router เลย)
app.use("/api/ie_code_list",        ieCodeUsageRouter);
app.use("/api/ie_code_list",        createTableRouter("ie_code_list"));
app.use("/api/access_requests",     createTableRouter("access_requests"));
app.use("/api/batch_list",          createTableRouter("batch_list"));
// MARKER_APP_ITEM_DESCRIPTION_FAVORITES_ROUTE_V1
app.use("/api/item_description_favorites", createTableRouter("item_description_favorites"));
// MARKER_APP_USER_TRANSACTIONS_DASHBOARD_WORKING_HOURS_GAP_V13
// -- Endpoint สำหรับ Popup "Transaction Dashboard" ใน System Console > Users --
// -- เปิดจาก UserManagement.js เมื่อกดชื่อ User ที่มี Permission Manual/IE ------
// -- Query สดจาก bucket_list ตรงๆ ไม่มีการเก็บ Summary ซ้ำในตารางใหม่ ----------
// MARKER_APP_USER_TRANSACTIONS_DASHBOARD_PERROW_FILLSTARTED_CORRECTION_V15
// -- เช็คทีละแถวแทนการเหมาบวก 7 ชม.ทั้งหมด เพราะข้อมูลจริงพิสูจน์แล้วว่าบาง --
// -- แถว fill_started_at ถูกเก็บถูกต้องอยู่แล้ว (ไม่ต้องบวก) ปนอยู่กับแถวที่ --
// -- ต้องบวก 7 ชม. (มาจาก Frontend คนละเวอร์ชัน) -- เลือกแบบที่ Gap เทียบกับ --
// -- created_at สมเหตุผล (0-4 ชม.) ถ้าไม่มีแบบไหนสมเหตุผลเลย Fallback เป็น --
// -- created_at (ปลอดภัยไว้ก่อน) --
const UTD_FILL_CORRECTED_COL = `
  CASE
    WHEN fill_started_at IS NULL THEN created_at AT TIME ZONE 'Asia/Bangkok'
    WHEN (created_at AT TIME ZONE 'Asia/Bangkok') - (fill_started_at AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Bangkok')
         BETWEEN INTERVAL '0 seconds' AND INTERVAL '4 hours'
      THEN (fill_started_at AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Bangkok')
    WHEN (created_at AT TIME ZONE 'Asia/Bangkok') - fill_started_at
         BETWEEN INTERVAL '0 seconds' AND INTERVAL '4 hours'
      THEN fill_started_at
    ELSE created_at AT TIME ZONE 'Asia/Bangkok'
  END
`;
const UTD_TS_COL     = UTD_FILL_CORRECTED_COL;
const UTD_MODULE_COL = "module";
const UTD_GROUP_COL  = "regexp_replace(regexp_replace(COALESCE(NULLIF(invoice_no, ''), local_id), '_NV$', '', 'i'), '/[0-9]+$', '')";
const UTD_MODULES    = ["AP", "IE", "COL-AP", "VAT"]; // MARKER_APP_USER_TRANSACTIONS_DASHBOARD_DOCCOLLECTION_COLAP_UNION_V2 (COALESCE confirmed_at/completed_at) -- เพิ่ม COL-AP (Query ตรงจาก doc_collection, ไม่ Shadow-Insert)
                                                       // MARKER_APP_USER_TRANSACTIONS_DASHBOARD_VAT_DRAFTID_UNION_V2 -- เพิ่ม VAT (Popvat/Simple/ADI, Group ตาม draft_id)
const UTD_AFTERHOURS_HOUR    = 18; // MARKER_APP_USER_TRANSACTIONS_DASHBOARD_WORKING_HOURS_GAP_V13 -- ส่งมาเฉยๆ เผื่อใช้งานอื่น ไม่มีผลกับ Gap อีกต่อไป (Frontend เลิก Highlight ด้วย Flag นี้แล้ว)
const UTD_WORKDAY_START_HOUR = 8;  // MARKER_APP_USER_TRANSACTIONS_DASHBOARD_WORKING_HOURS_GAP_V13 -- ช่วงเวลาทำงานที่ใช้คิด Gap: 08:00-19:00 (ยืนยันจาก User: "เริ่มนับ Gap ตั้งแต่ 8 โมง ถึง 1 ทุ่ม")
const UTD_WORKDAY_END_HOUR   = 19;

app.get("/api/user_transactions/dashboard", async (req, res) => {
  try {
    const { username, from, to, granularity } = req.query;
    if (!username || !from || !to) {
      return res.status(400).json({ error: "ต้องระบุ username, from, to" });
    }
    const gran = ["daily", "weekly", "monthly"].includes(granularity) ? granularity : "daily";
    const toExclusive = `${to} 23:59:59.999`;

    const baseSql = `
      WITH raw AS (
        SELECT
          ${UTD_GROUP_COL} AS grp_key,
          ${UTD_MODULE_COL} AS module,
          ${UTD_TS_COL} AS ts_real,
          ${UTD_FILL_CORRECTED_COL} AS fill_bkk, /* MARKER_APP_USER_TRANSACTIONS_DASHBOARD_PERROW_FILLSTARTED_CORRECTION_V15 */
          created_at AT TIME ZONE 'Asia/Bangkok' AS created_bkk,
          CASE WHEN jsonb_typeof(lines) = 'array' THEN jsonb_array_length(lines) ELSE 1 END AS line_count,
          fill_started_at IS NOT NULL AS has_fill_flag, /* MARKER_APP_USER_TRANSACTIONS_DASHBOARD_HAS_FILL_START_FLAG_V17 */
          bu,
          invoice_no,
          batch_id,
          vendor_name
        FROM bucket_list
        WHERE created_by = $1
          AND ${UTD_MODULE_COL} = ANY($4::text[])
          AND ${UTD_TS_COL} >= ($2::date - INTERVAL '2 days')
          AND ${UTD_TS_COL} <= $3::timestamp

        UNION ALL

        -- MARKER_APP_USER_TRANSACTIONS_DASHBOARD_DOCCOLLECTION_COLAP_UNION_V1 -- COL-AP: Query ตรงจาก doc_collection (Cross Check Confirm แล้วเท่านั้น) ไม่ Shadow-Insert ซ้ำเข้า bucket_list
        SELECT
          serial_code AS grp_key,
          'COL-AP' AS module,
          ((COALESCE(NULLIF(cross_check->>'confirmed_at',''), cross_check->>'completed_at'))::timestamptz AT TIME ZONE 'Asia/Bangkok') AS ts_real,
          (fill_started_at AT TIME ZONE 'Asia/Bangkok') AS fill_bkk,
          ((COALESCE(NULLIF(cross_check->>'confirmed_at',''), cross_check->>'completed_at'))::timestamptz AT TIME ZONE 'Asia/Bangkok') AS created_bkk,
          (CASE WHEN jsonb_typeof(rows) = 'array' THEN jsonb_array_length(rows) ELSE 1 END) AS line_count,
          (fill_started_at IS NOT NULL) AS has_fill_flag,
          bu_code AS bu, /* MARKER_APP_USER_TRANSACTIONS_DASHBOARD_COLAP_BU_INVOICE_FIX_V1 -- เดิมใช้ bu_code_name (Label "รหัส - ชื่อบริษัท" เช่น "5898 - Miracle Planet Co., Ltd.") ผิด ไม่ใช่ BU Code จริง -- เปลี่ยนเป็น bu_code ตรงๆ */
          (CASE WHEN jsonb_typeof(rows) = 'array' THEN (
             SELECT NULLIF(string_agg(DISTINCT v.val, ', '), '')
             FROM jsonb_array_elements(rows) elem
             CROSS JOIN LATERAL (
               SELECT COALESCE(
                 NULLIF(elem->>'Invoice Number', ''),
                 NULLIF(elem->>'Invoice Num', ''),
                 NULLIF(elem->>'Tax Invoice No.', '')
               ) AS val
             ) v
             WHERE v.val IS NOT NULL
           ) ELSE NULL END) AS invoice_no, /* MARKER_APP_USER_TRANSACTIONS_DASHBOARD_COLAP_INVOICE_FROM_ROWS_V1 -- ดึงเลข Invoice จริงจากระดับบรรทัดใน rows (Invoice Number/Invoice Num สำหรับ APN01, Tax Invoice No. สำหรับ AP09) รวมเป็น List คั่น ", " ถ้ามีหลายเลขใน Batch เดียวกัน (ไม่ Duplicate ค่าเดิมซ้ำ) */
          serial_code AS batch_id, /* MARKER_APP_USER_TRANSACTIONS_DASHBOARD_COLAP_BU_INVOICE_FIX_V1 */
          NULL::text AS vendor_name
        FROM doc_collection
        WHERE uploaded_by = $1
          AND doc_type IN ('APN01', 'AP09', 'AP07')
          AND (cross_check->>'confirmed')::boolean IS TRUE
          AND 'COL-AP' = ANY($4::text[])
          AND ((COALESCE(NULLIF(cross_check->>'confirmed_at',''), cross_check->>'completed_at'))::timestamptz AT TIME ZONE 'Asia/Bangkok') >= ($2::date - INTERVAL '2 days')
          AND ((COALESCE(NULLIF(cross_check->>'confirmed_at',''), cross_check->>'completed_at'))::timestamptz AT TIME ZONE 'Asia/Bangkok') <= $3::timestamp

        UNION ALL

        -- MARKER_APP_USER_TRANSACTIONS_DASHBOARD_VAT_DRAFTID_UNION_V2 -- VAT (Popvat/Simple/ADI): Group ตาม Draft_id เดียวกัน (ไม่ใช่ Invoice เพราะ 1 Draft มีได้หลาย Invoice/หลายบรรทัด) -- รวม 3 Table เป็น Transaction เดียวถ้า Draft_id ตรงกัน
        SELECT
          draft_id::text AS grp_key,
          'VAT' AS module,
          ${UTD_FILL_CORRECTED_COL} AS ts_real,
          ${UTD_FILL_CORRECTED_COL} AS fill_bkk,
          created_at AT TIME ZONE 'Asia/Bangkok' AS created_bkk,
          line_count, /* MARKER_APP_USER_TRANSACTIONS_VAT_ARCHIVE_UNION_V1 -- ปกติ 1 ต่อแถว แต่แถว Archive (Draft ที่ลบหลังครบ 6 เดือน) เก็บยอดรวมไว้ในนี้ */
          fill_started_at IS NOT NULL AS has_fill_flag,
          bu::text AS bu,
          draft_id::text AS invoice_no,
          batch_id::text AS batch_id,
          NULL::text AS vendor_name
        FROM (
          SELECT draft_id, username, bu, fill_started_at, created_at, batch_id, 1 AS line_count FROM vat_upload_popvatdraft
          UNION ALL
          SELECT draft_id, username, bu, fill_started_at, created_at, batch_id, 1 AS line_count FROM vat_simpleinputdraft
          UNION ALL
          SELECT draft_id, username, bu, fill_started_at, created_at, batch_id, 1 AS line_count FROM vat_adi_transferdraft
          UNION ALL
          SELECT draft_id, username, bu, fill_started_at, created_at, batch_id, line_count FROM vat_transaction_archive
          UNION ALL
          SELECT 'RECON-' || id::text AS draft_id, owner_username AS username, bu, fill_started_at, created_at, NULL AS batch_id, 1 AS line_count FROM file_storage WHERE module = 'vat-reconcile-report' -- MARKER_VATRECONCILE_USER_TRANSACTION_V1 -- Reconcile Report: Save (Export) 1 ครั้ง = 1 Job, เริ่มนับจากเลือก Period (fill_started_at)
        ) vat_all
        WHERE username = $1
          AND draft_id IS NOT NULL AND draft_id <> ''
          AND 'VAT' = ANY($4::text[])
          AND ${UTD_FILL_CORRECTED_COL} >= ($2::date - INTERVAL '2 days')
          AND ${UTD_FILL_CORRECTED_COL} <= $3::timestamp
      ),
      per_invoice AS (
        SELECT
          grp_key, MIN(module) AS module, MIN(ts_real) AS ts_real,
          SUM(line_count) AS sub_items,
          MIN(fill_bkk) AS work_start_raw, MAX(created_bkk) AS work_end,
          bool_or(has_fill_flag) AS has_fill_start, /* MARKER_APP_USER_TRANSACTIONS_DASHBOARD_HAS_FILL_START_FLAG_V17 */
          MIN(bu) AS bu, MIN(invoice_no) AS invoice_no, MIN(batch_id) AS batch_id, MIN(vendor_name) AS vendor_name
        FROM raw
        GROUP BY grp_key
      ),
      adj AS (
        SELECT
          grp_key, module, sub_items, bu, invoice_no, batch_id, vendor_name,
          has_fill_start, /* MARKER_APP_USER_TRANSACTIONS_DASHBOARD_HAS_FILL_START_FLAG_V17 */
          ts_real,
          ts_real AS ts,
          COALESCE(work_start_raw, ts_real) AS start_ts, -- MARKER_APP_USER_TRANSACTIONS_DASHBOARD_START_END_TIME_V14 -- เวลาเริ่มกรอก (fill_started_at) ถ้าไม่มี Fallback เป็น ts_real
          work_end AS end_ts, -- MARKER_APP_USER_TRANSACTIONS_DASHBOARD_START_END_TIME_V14 -- เวลา Submit จริง (created_at)
          (EXTRACT(HOUR FROM ts_real) >= ${UTD_AFTERHOURS_HOUR}) AS is_after_hours,
          (EXTRACT(DOW FROM ts_real) IN (0, 6)) AS is_weekend_source, -- MARKER_APP_USER_TRANSACTIONS_DASHBOARD_WORKING_HOURS_GAP_V13 -- Transaction ที่ทำจริงในวันเสาร์(6)/อาทิตย์(0) เอาไว้ให้ Frontend โชว์บน Timeline เฉยๆ ไม่เอาไปคิด Gap
          (
            EXTRACT(HOUR FROM ts_real) >= ${UTD_WORKDAY_START_HOUR}
            AND EXTRACT(HOUR FROM ts_real) < ${UTD_WORKDAY_END_HOUR}
            AND NOT (EXTRACT(DOW FROM ts_real) IN (0, 6))
          ) AS is_gap_eligible, -- MARKER_APP_USER_TRANSACTIONS_DASHBOARD_WORKING_HOURS_GAP_V13 -- อยู่ในช่วงเวลาทำงาน (08:00-19:00) และไม่ใช่วันหยุด ถึงจะเอาไปคิด Gap ได้
          CASE EXTRACT(DOW FROM ts_real)
               WHEN 6 THEN (ts_real::date + 2)
               WHEN 0 THEN (ts_real::date + 1)
               ELSE ts_real::date END AS business_date,
          CASE
            WHEN work_end IS NOT NULL AND COALESCE(work_start_raw, ts_real) IS NOT NULL
                 AND work_end > COALESCE(work_start_raw, ts_real) AND sub_items > 0
            THEN ROUND((EXTRACT(EPOCH FROM (work_end - COALESCE(work_start_raw, ts_real))) / 60.0 / sub_items)::numeric, 1)
            ELSE NULL
          END AS per_trans_minutes
        FROM per_invoice
      )
    `;

    if (gran === "daily") {
      const { rows } = await pool.query(
        baseSql + `
        SELECT
          grp_key, module, ts, ts_real, start_ts, end_ts, has_fill_start, is_after_hours, is_weekend_source, sub_items, per_trans_minutes, bu, invoice_no, batch_id, vendor_name, /* MARKER_APP_USER_TRANSACTIONS_DASHBOARD_START_END_TIME_V14 MARKER_APP_USER_TRANSACTIONS_DASHBOARD_HAS_FILL_START_FLAG_V17 */
          CASE WHEN is_gap_eligible AND LAG(is_gap_eligible) OVER (ORDER BY ts)
               THEN EXTRACT(EPOCH FROM (ts - LAG(ts) OVER (ORDER BY ts))) / 60
               ELSE NULL END AS gap_minutes
        FROM adj
        WHERE business_date = $2::date
        ORDER BY ts ASC`,
        [username, from, toExclusive, UTD_MODULES]
      );
      const totalSubItems = rows.reduce((s, r) => s + Number(r.sub_items || 0), 0);
      const gapValues = rows.filter(r => r.gap_minutes != null).map(r => Number(r.gap_minutes)); // MARKER_APP_USER_TRANSACTIONS_DASHBOARD_WORKING_HOURS_GAP_V13 -- เฉลี่ยเฉพาะ Gap ที่นับจริง (อยู่ในช่วงเวลาทำงานต่อเนื่องกัน) ไม่หารด้วยจำนวนแถวทั้งหมด
      const summary = rows.length ? {
        start_time: rows[0].ts,
        end_time: rows[rows.length - 1].ts,
        count: totalSubItems,
        avg_gap_minutes: gapValues.length
          ? Math.round((gapValues.reduce((s, g) => s + g, 0) / gapValues.length) * 10) / 10
          : null,
      } : { start_time: null, end_time: null, count: 0, avg_gap_minutes: null };

      // MARKER_VATRECONCILE_ACTIVITY_TS_V1 -- แสดง Timestamp การทำงานในหน้า Reconcile (เลือก Period / ตรวจสอบ Expired / Save / Confirm / Release / ส่ง SharePoint) เป็นแถวเพิ่ม
      // -- แสดงอย่างเดียว ไม่คำนวณ: sub_items = 0, ไม่มี Per Trans / Gap, ไม่รวมใน summary / จำนวน Transaction | Invoice No. / Module / Batch ไม่มี = null
      let tsRows = [];
      try {
        const tsq = await pool.query(
          `SELECT id, event, bu, account, period, file_id, (created_at AT TIME ZONE 'Asia/Bangkok') AS ts
             FROM vat_reconcile_activity_ts
            WHERE username = $1
              AND (CASE EXTRACT(DOW FROM (created_at AT TIME ZONE 'Asia/Bangkok'))
                     WHEN 6 THEN ((created_at AT TIME ZONE 'Asia/Bangkok')::date + 2)
                     WHEN 0 THEN ((created_at AT TIME ZONE 'Asia/Bangkok')::date + 1)
                     ELSE (created_at AT TIME ZONE 'Asia/Bangkok')::date END) = $2::date
            ORDER BY created_at ASC LIMIT 2000`, [username, from]);
        tsRows = tsq.rows.map((t) => ({
          grp_key: "TS-" + t.id, module: null, ts: t.ts, ts_real: t.ts, start_ts: t.ts, end_ts: t.ts,
          has_fill_start: false, is_after_hours: false, is_weekend_source: false, sub_items: 0, per_trans_minutes: null,
          bu: t.bu || null, invoice_no: null, batch_id: null, vendor_name: null, gap_minutes: null,
          is_timestamp: true, event: t.event, account: t.account || null, period: t.period || null,
        }));
      } catch (e) { if (e.code !== "42P01") console.error("[user_transactions] activity ts error:", e.message); }
      try { // Timestamp จาก activity_log (ทุก Action ที่บันทึกไว้) -- แสดงอย่างเดียว
        const alq = await pool.query(
          `SELECT id, action, module, (created_at AT TIME ZONE 'Asia/Bangkok') AS ts
             FROM activity_log
            WHERE username = $1 AND action NOT ILIKE '%OCR%'
              AND (CASE EXTRACT(DOW FROM (created_at AT TIME ZONE 'Asia/Bangkok'))
                     WHEN 6 THEN ((created_at AT TIME ZONE 'Asia/Bangkok')::date + 2)
                     WHEN 0 THEN ((created_at AT TIME ZONE 'Asia/Bangkok')::date + 1)
                     ELSE (created_at AT TIME ZONE 'Asia/Bangkok')::date END) = $2::date
            ORDER BY created_at ASC LIMIT 2000`, [username, from]);
        for (const t of alq.rows) tsRows.push({
          grp_key: "AL-" + t.id, module: null, ts: t.ts, ts_real: t.ts, start_ts: t.ts, end_ts: t.ts,
          has_fill_start: false, is_after_hours: false, is_weekend_source: false, sub_items: 0, per_trans_minutes: null,
          bu: null, invoice_no: null, batch_id: null, vendor_name: null, gap_minutes: null,
          is_timestamp: true, event: t.action, module_src: t.module || null, account: null, period: null,
        });
      } catch (e) { console.error("[user_transactions] activity_log ts error:", e.message); }
      const merged = rows.concat(tsRows).sort((x, y) => new Date(x.ts) - new Date(y.ts));
      return res.json({ granularity: "daily", from, to, summary, transactions: merged });
    }

    const { rows } = await pool.query(
      baseSql + `
      SELECT business_date AS date, module, SUM(sub_items) AS count
      FROM adj
      WHERE business_date BETWEEN $2::date AND $3::date
      GROUP BY business_date, module
      ORDER BY business_date ASC`,
      [username, from, toExclusive, UTD_MODULES]
    );

    const byDate = {};
    for (const r of rows) {
      const d = r.date instanceof Date ? r.date.toISOString().slice(0, 10) : String(r.date).slice(0, 10);
      if (!byDate[d]) byDate[d] = { date: d, count: 0, modules: {} };
      byDate[d].count += Number(r.count);
      byDate[d].modules[r.module] = (byDate[d].modules[r.module] || 0) + Number(r.count);
    }
    const days = Object.values(byDate).sort((a, b) => a.date.localeCompare(b.date));
    const totalCount = days.reduce((s, d) => s + d.count, 0);
    const activeDays = days.filter(d => d.count > 0).length;

    return res.json({
      granularity: gran,
      from, to,
      summary: {
        total_count: totalCount,
        active_days: activeDays,
        avg_per_day: activeDays ? Math.round((totalCount / activeDays) * 10) / 10 : 0,
      },
      days,
    });
  } catch (err) {
    console.error("GET /api/user_transactions/dashboard error:", err.message);
    res.status(500).json({ error: "Internal server error" });
  }
});
app.use("/api/bucket_list",         createTableRouter("bucket_list"));
app.use("/api/doc_access_override", createTableRouter("doc_access_override"));
app.use("/api/menu_access_override", createTableRouter("menu_access_override")); // MARKER_MOUNT_MENU_ACCESS_OVERRIDE_V1
app.use("/api/activity_log",        createTableRouter("activity_log"));
app.use("/api/ap_active_sessions",  createTableRouter("ap_active_sessions"));
// MARKER_APP_MOUNT_IE_ACTIVE_SESSIONS_V1 -- แก้ Heartbeat 404 (idColumn เป็น batch_id ตามที่ Frontend upsert(onConflict:'batch_id'))
app.use("/api/ie_active_sessions", createTableRouter("ie_active_sessions", { idColumn: "batch_id" }));
app.use("/api/menu_active_sessions", createTableRouter("menu_active_sessions", { idColumn: "session_id" }));
app.use("/api/doc_files",           createTableRouter("doc_files"));
app.use("/api/doc_collection",      createTableRouter("doc_collection"));
app.use("/api/recycle_bin",         createTableRouter("recycle_bin"));
app.use("/api/batch_notifications", createTableRouter("batch_notifications"));
app.use("/api/notifications",       createTableRouter("notifications"));
// MARKER_APP_MOUNT_SUPPORT_THREADS_ROUTER_V1 -- Frontend Query severity/log_number/status ตรงๆ (Homepage.js)
app.use("/api/support_threads",     createTableRouter("support_threads"));
// MARKER_APP_MOUNT_SUPPORT_THREAD_SHARES_ROUTER_V1 -- Homepage.js Query หา Thread ที่ถูก Share มาให้ตัวเอง (ไม่งั้น 404 เงียบๆ ไม่มี Error โชว์เลย)
app.use("/api/support_thread_shares", createTableRouter("support_thread_shares"));

// error handler กลาง
app.use((err, req, res, next) => {
  console.error('ERROR on:', req.method, req.path);
  console.error(err.message);
  res.status(500).json({ error: "Internal server error" });
});

// MARKER_CLEANUP_APPROVED_NOTIF_V1
// -- ?? batch_notifications ??? Approve ???? (status='approved') ??????? 1 ??. --
// -- ?????????? created_at ?????? Reset ????? Approve ?? APController.js ------
async function checkAndCleanupApprovedNotifications() {
  await pool.query(
    `DELETE FROM batch_notifications WHERE status = 'approved' AND created_at < NOW() - INTERVAL '1 hour'`
  );
}

// MARKER_BATCH_LIST_15DAY_RETENTION_V1
// MARKER_FIX_RECYCLE_BIN_SCHEMA_V1
// -- Phase 4: ?? batch_list ??????? 15 ??? (?????? created_at) ------------
// -- ???????? recycle_bin ???????? (Soft Delete Pattern ????????????????) --
// -- ?????? bucket_list (Invoice History) ??? � ???? Backup ???????????? --
// -- Batch Comments (Chat) Retention ----------------------------------
// -- ??????? Batch ???? Approve ???? ??? approved_at ???? 7 ??? ---------
// -- ?????? approved_at ??????????? batch_list ??? (Single Source) -----
// -- Batch ????????? Approve (Rejected/???? Processing) ????????????? ----
async function checkAndCleanupBatchComments() {
  const { rows: expired } = await pool.query(
    `SELECT DISTINCT bc.batch_id FROM batch_comments bc
     JOIN batch_list bl ON bl.batch_id = bc.batch_id
     WHERE bl.status = 'approved'
       AND bl.approved_at IS NOT NULL
       AND bl.approved_at < NOW() - INTERVAL '7 days'`
  );

  for (const row of expired) {
    const dir = path.join(CHAT_STORAGE_ROOT, String(row.batch_id));
    if (fs.existsSync(dir)) {
      fs.rmSync(dir, { recursive: true, force: true });
    }
  }

  if (expired.length) {
    await pool.query(
      `DELETE FROM batch_comments
       USING batch_list
       WHERE batch_comments.batch_id = batch_list.batch_id
         AND batch_list.status = 'approved'
         AND batch_list.approved_at < NOW() - INTERVAL '7 days'`
    );
  }
}

async function checkAndCleanupBatchList() {
  await pool.query(
    `WITH moved AS (
       DELETE FROM batch_list
       -- MARKER_BATCHLIST_RETENTION_APPROVED_AT_V1
       WHERE approved_at IS NOT NULL
         AND approved_at < NOW() - INTERVAL '15 days'
       RETURNING *
     )
     INSERT INTO recycle_bin (source_table, source_id, source_key, data, deleted_by, deleted_at)
     SELECT 'batch_list', moved.id, moved.batch_id, to_jsonb(moved.*), 'system-cron-15day-retention', NOW()
     FROM moved`
  );
}

// MARKER_RECYCLEBIN_PURGE_30DAY_V1 -- ลบถาวรทุก Record ใน recycle_bin (ทุก Table รวมกัน) ที่เก่าเกิน 30 วัน
// (recycle_bin เป็นด่านสุดท้ายอยู่แล้ว -- ไม่ต้อง Archive ต่อไปไหนอีก ลบทิ้งจริงเลย)
async function checkAndPurgeRecycleBin() {
  await pool.query(
    `DELETE FROM recycle_bin WHERE deleted_at < NOW() - INTERVAL '30 days'`
  );
}

// Patch 94: Retention 1 เดือนเฉพาะ OCR Log ใน activity_log (action =
// 'ocr_completed'/'ocr_failed' ที่มาจาก AP OCR + DocCenter OCR หลัง Patch 93)
// เพราะถูกสร้างถี่มากทุกครั้งที่ Set ปิด ต่างจาก Action อื่น (เช่น อนุมัติ
// Serial) ที่ไม่ถี่เท่า จึงยังคงเก็บถาวรตามเดิม ไม่ลบทิ้งเป็น Log ทั่วไป
// ที่ไม่มีการกรอง action เลย
async function checkAndCleanupOcrActivityLog() {
  await pool.query(
    `DELETE FROM activity_log
     -- MARKER_ACTIVITYLOG_OCR_RETENTION_1MONTH_V1
     WHERE action IN ('ocr_completed', 'ocr_failed')
       AND created_at < NOW() - INTERVAL '1 month'`
  );
}

// MARKER_APP_IE_SIMPLE_DRAFTID_REMAP_CRON_V1 -- Safety Net: Remap draft_id ของ ie_simplevatdraft ที่ยังค้างเป็น Local ID
// (local-xxx) ทั้งที่ Invoice ต้นทางถูก Batch Export ไปแล้วจริง (bucket_list.batch_id
// IS NOT NULL) -- เก็บตกกรณี Remap ตอน Export (Frontend, วิธีที่ 1) พลาดไปด้วยสาเหตุใดก็ตาม
async function checkAndRemapIeSimpleDraftId() {
  const { rows } = await pool.query(
    `SELECT s.id AS simple_id, b.id AS bucket_id
     FROM ie_simplevatdraft s
     JOIN bucket_list b ON b.local_id = s.draft_id
     WHERE s.menu_source = 'ie_vat'
       AND s.status = 'pre-export'
       AND s.draft_id LIKE 'local-%'
       AND b.batch_id IS NOT NULL`
  );
  for (const row of rows) {
    await pool.query(`UPDATE ie_simplevatdraft SET draft_id = $1 WHERE id = $2`, [String(row.bucket_id), row.simple_id]);
  }
}

// MARKER_APP_MAINTENANCE_COUNTDOWN_CRON_V1 -- Cron ฝั่ง Server เป็นคนจริงที่ Flip maintenance_mode ตอนหมดเวลา
// (ไม่ต้องพึ่ง Client/Owner เปิดหน้าเว็บอยู่ตอนนั้น -- แก้ช่องโหว่ของวิธี
// Client-only เดิม ที่ถ้าไม่มี Owner Online ตอนหมดเวลา จะไม่มีใคร Flip Flag)
async function checkAndEnforceMaintenanceSchedule() {
  const { rows } = await pool.query(
    `SELECT key, value FROM system_settings WHERE key IN ('maintenance_mode', 'maintenance_scheduled_at')`
  );
  const settings = {};
  rows.forEach(r => { settings[r.key] = r.value; });
  const scheduledAt = settings.maintenance_scheduled_at || '';
  const isClosedNow = settings.maintenance_mode === 'true';
  if (!scheduledAt || isClosedNow) return; // ไม่มี Countdown ค้างอยู่ หรือปิดไปแล้วอยู่แล้ว -- ไม่ต้องทำอะไร
  const remainingMs = new Date(scheduledAt).getTime() - Date.now();
  if (remainingMs > 0) return; // ยังไม่ถึงเวลา
  const nowIso = new Date().toISOString();
  await pool.query(
    `INSERT INTO system_settings (key, value, updated_by, updated_at) VALUES ($1, $2, $3, $4)
     ON CONFLICT (key) DO UPDATE SET value = $2, updated_by = $3, updated_at = $4`,
    ['maintenance_mode', 'true', 'system-cron', nowIso]
  );
  await pool.query(
    `INSERT INTO system_settings (key, value, updated_by, updated_at) VALUES ($1, $2, $3, $4)
     ON CONFLICT (key) DO UPDATE SET value = $2, updated_by = $3, updated_at = $4`,
    ['maintenance_scheduled_at', '', 'system-cron', nowIso]
  );
  wsBroadcast('maintenance_mode_changed', { key: 'maintenance_mode', value: 'true' });
  console.log('[Maintenance Cron] Countdown หมดเวลา -- ปิด Full Maintenance โดยอัตโนมัติ (Server-side)');
}

const port = process.env.PORT || 4000;

// -- WebSocket Server � Real-time push ????? Client --------------------------
// -- Frontend ?????? ws://host:4000 ??????? event ????? reload ?????? --------
export function wsBroadcast(event, data = {}) {
  if (!global._wss) return;
  const msg = JSON.stringify({ event, ...data });
  global._wss.clients.forEach(client => {
    if (client.readyState === 1) client.send(msg);
  });
}

const server = app.listen(port, "0.0.0.0", () => {
  console.log(`API running on port ${port}`);

  // -- Attach WebSocket Server ????? HTTP Server ???? (port ????????) --
  const wss = new WebSocketServer({ server });
  global._wss = wss;

  // -- Heartbeat: ??? Firewall/Proxy/VPN ??? Connection ???????? Traffic ??????? --
  // -- (?????????????? 60-120 ??) ??? ping ??? 30 ?? ??? client ?????? pong ????? --
  // -- ???????? ????????????? -> terminate() ???? (??? memory leak client ????) --
  // -- Browser ??? pong ??????????????? WebSocket protocol ?????????????? Frontend --
  function markAlive() { this.isAlive = true; }
  // MARKER_APP_WS_PRESENCE_V2 -- Presence (เข้า/ออกระบบของทีม) ให้ Backend เป็นผู้ตัดสินทั้งหมด
  // -- ส่ง 'team_presence' เฉพาะ Client ที่ "ควรเห็น" (Owner เห็นทุกคน / คนอื่นต้องมี Permission ซ้อนกัน)
  // -- Frontend แค่แสดง Toast ตามที่ได้รับ ไม่ต้อง Query/Dedupe/เดาเอง
  const TEAM_PERMISSION_KEYS = ['VAT', 'I-Pro', 'GL', 'IE', 'Function', 'Manual', 'ApproveBatch'];
  const PRESENCE_GRACE_MS = 8000; // Refresh/Reconnect กลับมาทันภายในเวลานี้ = ไม่ถือว่าออกจากระบบ
  const presenceGrace = new Map(); // username -> Timeout (รอ Offline)
  const hasOtherConn = (self) => [...wss.clients].some(c => c !== self && c.readyState === 1 && c.username === self.username);

  async function announcePresence(subject, kind) {
    try {
      const recipients = [...wss.clients].filter(c => c.readyState === 1 && c.username && c.username !== subject);
      if (recipients.length === 0) return;
      const names = [...new Set([subject, ...recipients.map(c => c.username)])];
      const { rows } = await pool.query(
        `SELECT username, role, permissions FROM user_roles WHERE username = ANY($1)`,
        [names]
      );
      const byName = new Map(rows.map(r => [r.username, r]));
      const subj = byName.get(subject);
      const msg = JSON.stringify({ event: 'team_presence', id: `${subject}|${kind}|${Date.now()}`, username: subject, kind });
      for (const c of recipients) {
        const me = byName.get(c.username);
        if (!me) continue;
        const isOwner = me.role === 'Owner';
        const overlap = TEAM_PERMISSION_KEYS.some(k => me.permissions?.[k] && subj?.permissions?.[k]);
        if (isOwner || overlap) { try { c.send(msg); } catch (e) {} }
      }
    } catch (e) { console.error('[WS presence] announce error:', e.message); }
  }

  async function goOffline(u) {
    try {
      await pool.query(`DELETE FROM menu_active_sessions WHERE session_id = $1`, [u]);
    } catch (e) { console.error('[WS presence] cleanup menu_active_sessions error:', e.message); }
    lastMenuByUser.delete(u);
    logActivity(u, "LOGOUT", "AUTH"); // MARKER_APP_MENU_ENTER_ACTIVITY_V1
    wsBroadcast('team_status_updated', { username: u, online: false }); // ให้ Home/Sidebar Refresh รายชื่อทีม
    announcePresence(u, 'logout');
  }

  wss.on('connection', (ws, req) => {
    ws.isAlive = true;
    // MARKER_APP_WS_DISCONNECT_OFFLINE_V1
    // ── อ่าน Username จาก Query String (?user=xxx ที่ wsManager.js ส่งมา) ──
    // ── เก็บไว้ที่ ws.username เพื่อรู้ว่า Connection นี้เป็นของใคร ──────────
    try {
      const url = new URL(req.url, `http://${req.headers.host}`);
      ws.username = url.searchParams.get('user') || null;
    } catch (e) { ws.username = null; }
    // MARKER_APP_WS_PRESENCE_V2 -- Backend คุม Login/Logout Presence เอง (Source of Truth) ไม่พึ่ง Frontend ยิง Event
    // -- ถ้า User นี้เพิ่งหลุดและกำลังรอ Grace (Refresh/เน็ตสะดุด) แล้วกลับเข้ามาทัน = ยังไม่ใช่ Login ใหม่ ไม่ประกาศอะไร
    if (ws.username) {
      const pendingOffline = presenceGrace.get(ws.username);
      if (pendingOffline) {
        clearTimeout(pendingOffline);
        presenceGrace.delete(ws.username);
      } else if (!hasOtherConn(ws)) {
        wsBroadcast('team_status_updated', { username: ws.username }); // ให้ Home/Sidebar Refresh รายชื่อทีม
        lastMenuByUser.delete(ws.username); // Login ใหม่ -> Heartbeat แรกนับเป็นเข้าเมนู
        announcePresence(ws.username, 'login');
      }
    }
    ws.on('pong', markAlive);
    ws.on('error', (err) => console.error('[WS] client error:', err.message));
    // ── Connection ขาด (ปิด Tab/เน็ตหลุด/Heartbeat Terminate ก็เข้าทางนี้ ──
    // ── เหมือนกัน เพราะ ws.terminate() ก็ Trigger 'close' Event ปกติ) ──────
    // ── ลบ Session ทันที + Broadcast ให้คนอื่นเห็น Offline แบบ Real-time ────
    // ── ไม่ต้องรอ Cutoff 5 นาทีจาก last_seen อีกต่อไป ──────────────────────
    ws.on('close', (code) => {
      if (!ws.username) return;
      const u = ws.username;
      if (hasOtherConn(ws)) return; // MARKER_APP_WS_CLOSE_LAST_CONN_ONLY_V1 -- ยังมี Connection อื่นของ User เดียวกันเปิดอยู่ = ยังไม่ Offline จริง
      // MARKER_APP_WS_PRESENCE_V2 -- code 4000 = Frontend Logout/Force Logout ตั้งใจปิด -> Offline ทันที
      // -- code อื่น (ปิดแท็บ/Refresh/เน็ตหลุด/Heartbeat Terminate) -> รอ Grace กัน Refresh แล้วขึ้น Logout ปลอม
      if (code === 4000) {
        const pending = presenceGrace.get(u);
        if (pending) { clearTimeout(pending); presenceGrace.delete(u); }
        goOffline(u);
        return;
      }
      if (presenceGrace.has(u)) return;
      presenceGrace.set(u, setTimeout(() => {
        presenceGrace.delete(u);
        if (![...wss.clients].some(c => c.readyState === 1 && c.username === u)) goOffline(u);
      }, PRESENCE_GRACE_MS));
    });
  });
  const wsHeartbeatInterval = setInterval(() => {
    wss.clients.forEach((ws) => {
      if (ws.isAlive === false) return ws.terminate();
      ws.isAlive = false;
      ws.ping();
    });
  }, 30000);
  wss.on('close', () => clearInterval(wsHeartbeatInterval));

  console.log(`WebSocket ready on ws://0.0.0.0:${port}`);

  // ── Cron Job: เก็บ RAM Snapshot + เช็ค Auto-Close AP Period ทุก 5 นาที ──
  const RAM_SNAPSHOT_INTERVAL_MS = 5 * 60 * 1000;
  // MARKER_APP_DATAINTEGRITY_REMOVED_V1 -- ถอด DATA_INTEGRITY_CHECK_INTERVAL_MS ออกแล้ว (ไม่ใช้แล้ว)
  setInterval(async () => {
    try {
      await takeRamSnapshot();
      wsBroadcast("ram_snapshot_updated", {}); // frontend fetch ข้อมูลล่าสุดเองผ่าน endpoint เดิม
    } catch (err) {
      console.error("RAM snapshot cron error:", err.message);
    }
    try {
      await takeCpuSnapshot();
      wsBroadcast("cpu_snapshot_updated", {});
    } catch (err) {
      console.error("CPU snapshot cron error:", err.message);
    }
    try {
      await checkAutoCloseRequest();
    } catch (err) {
      console.error("Auto-close AP period cron error:", err.message);
    }
    try {
      await checkAndSyncPeriodStatus();
    } catch (err) {
      console.error("Sync AP period status cron error:", err.message);
    }
    try {
      await checkAutoCloseIERequest();
    } catch (err) {
      console.error("Auto-close IE period cron error:", err.message);
    }
    try {
      await checkAndSyncIEPeriodStatus();
    } catch (err) {
      console.error("Sync IE period status cron error:", err.message);
    }
    // MARKER_VATPERIOD_NO_CRON_V1 -- VAT ไม่ต้องมี Cron เพราะไม่มี Pre-close/Blocked/Request-Close ให้ Sync (ตกลงกันไว้ก่อนหน้าแล้ว)
    try {
      await checkAndCleanupFileStorage();
    } catch (err) {
      console.error("File storage cleanup cron error:", err.message);
    }
    try {
      await checkAndCleanupSupportThreads();
    } catch (err) {
      console.error("Support & Feedback recycle bin cleanup cron error:", err.message);
    }
    try {
      await checkSupportThreadReminders();
    } catch (err) {
      console.error("Support & Feedback reminder cron error:", err.message);
    }
    try {
      await checkAutoAgreeThreads();
    } catch (err) {
      console.error("Support & Feedback auto-agree cron error:", err.message);
    }
    try {
      await checkTestingRecall();
    } catch (err) {
      console.error("Support & Feedback testing-recall cron error:", err.message);
    }
    try {
      await checkAndRestoreNewThreadNotifications();
    } catch (err) {
      console.error("Support & Feedback restore new-thread notification cron error:", err.message);
    }
    try {
      await checkAndCleanupExpiredAcceptNotifications();
    } catch (err) {
      console.error("Support & Feedback accept-expiry cron error:", err.message);
    }
    try {
      await checkAndCleanupApprovedNotifications();
    } catch (err) {
      console.error("Approved notifications cleanup cron error:", err.message);
    }
    try {
      await checkAndCleanupBatchList();
    } catch (err) {
      console.error("batch_list 15-day retention cron error:", err.message);
    }
    try {
      await checkAndPurgeRecycleBin(); // MARKER_RECYCLEBIN_PURGE_30DAY_V1
    } catch (err) {
      console.error("recycle_bin 30-day purge cron error:", err.message);
    }
    try {
      await checkAndCleanupBatchComments();
    } catch (err) {
      console.error("batch_comments retention cron error:", err.message);
    }
    try {
      await checkAndCleanupOcrActivityLog();
    } catch (err) {
      console.error("activity_log OCR retention cron error:", err.message);
    }
    try {
      await purgeExpiredTaxClosePeriods(); // MARKER_TAXCLOSE_LIFECYCLE_V1 -- ล้างข้อมูล Timeline ปิดภาษีหลังปิด Period ครบ N วัน
    } catch (err) {
      console.error("tax close timeline purge cron error:", err.message);
    }
    try {
      await checkAndRemapIeSimpleDraftId();
    } catch (err) {
      console.error("IE Simple draft_id remap cron error:", err.message); // MARKER_APP_IE_SIMPLE_DRAFTID_REMAP_CRON_V1
    }
    try {
      await autoCleanJunk();
    } catch (err) {
      console.error("auto clean junk cron error:", err.message);
    }
    try {
      await checkAndCleanupUnmatchedNotes(); // MARKER_APP_NOTES_CLEANUP_UNMATCHED_V1
    } catch (err) {
      console.error("vat_watchlist_notes unmatched cleanup cron error:", err.message);
    }
  }, RAM_SNAPSHOT_INTERVAL_MS);

  // MARKER_APP_DATAINTEGRITY_REMOVED_V1 -- ถอด Cron ตรวจ bucket_list Branch Label ว่างออกแล้ว (2026-09-28)
  // เดิมเรียก checkBucketListDataIntegrity() ทุก DATA_INTEGRITY_CHECK_INTERVAL_MS -- ดูเหตุผลที่ import ด้านบนไฟล์

  // MARKER_DOCCOLLECTION_AUTOCONFIRM_CRON_V1 -- Cron Auto-Confirm Cross Check (doc_collection) (2026-09-28)
  // เหตุผล: Cross Check ยังคงบังคับทำตามปกติ (ไม่เปลี่ยน Gate การ Download ใดๆ) แต่ถ้าเอกสารถูกโหลดออก
  // ไปแล้ว (ผ่านช่องทางที่ไม่ผ่าน Gate เช่นปุ่ม "PDF"/รูปแนบ หรือโหลดผ่าน Gate ตามปกติ) และผ่านมาแล้ว
  // 6 ชม.นับจาก downloaded_at โดยยังไม่มีใครกด Confirm เอง ให้ระบบ Confirm ให้อัตโนมัติ (นับว่า "ถือว่า
  // ตรวจแล้ว" เพราะไฟล์ถูกใช้งานออกไปจริง) เงื่อนไขครบ 3 อย่าง: fill_started_at, created_at, downloaded_at
  // ต้องไม่ว่างทั้งหมด และ downloaded_at ต้องผ่านมาแล้ว >= 6 ชม. -- ใช้ downloaded_at เป็นฐานเวลาเพราะเป็น
  // Trigger ตัวสุดท้ายที่เกิดขึ้นจริง (ถ้ายังไม่เคยโหลดเลย จะไม่มีวัน Auto-Confirm — ยังคงบังคับต้องทำ
  // Cross Check ปกติอยู่ดี) ยกเว้นเคส AP09/Inputsummary ที่ Auto-Confirm ตั้งแต่ตอน Save อยู่แล้ว (ไม่เข้าเงื่อนไขนี้
  // เพราะ cross_check.confirmed เป็น true อยู่ก่อนแล้ว) -- ต้อง ALTER TABLE doc_collection ADD COLUMN
  // downloaded_at TIMESTAMP ก่อน Deploy ไฟล์นี้ (ดู schema/doc_collection_downloaded_at_v1.sql)
  const DOCCOLLECTION_AUTOCONFIRM_INTERVAL_MS = 30 * 60 * 1000; // เช็คทุก 30 นาที
  const DOCCOLLECTION_AUTOCONFIRM_HOURS = 6;
  setInterval(async () => {
    try {
      const { rows } = await pool.query(
        `UPDATE doc_collection
         SET cross_check = COALESCE(cross_check, '{}'::jsonb)
                            || jsonb_build_object(
                                 'confirmed', true,
                                 'confirmed_at', to_jsonb(NOW()),
                                 'confirmed_by', 'system-auto-6h',
                                 'completed_at', to_jsonb(NOW())
                               )
         WHERE status <> 'draft'
           AND fill_started_at IS NOT NULL
           AND created_at IS NOT NULL
           AND downloaded_at IS NOT NULL
           AND downloaded_at <= NOW() - INTERVAL '${DOCCOLLECTION_AUTOCONFIRM_HOURS} hours'
           AND COALESCE((cross_check->>'confirmed')::boolean, false) = false
         RETURNING id, serial_code`
      );
      if (rows.length > 0) {
        console.log(`[MARKER_DOCCOLLECTION_AUTOCONFIRM_CRON_V1] Auto-confirmed ${rows.length} doc_collection row(s):`, rows.map(r => r.serial_code || r.id).join(', '));
      }
    } catch (err) {
      console.error('[MARKER_DOCCOLLECTION_AUTOCONFIRM_CRON_V1] error:', err.message);
    }
  }, DOCCOLLECTION_AUTOCONFIRM_INTERVAL_MS);

  // MARKER_APP_MAINTENANCE_COUNTDOWN_CRON_V1 -- เช็คถี่กว่า Cron อื่น (15 วิ) เพราะ Query เดียวเบามาก
  // และ User ต้องการให้ปิดตรงเวลาที่ตั้ง Countdown ไว้ ไม่ใช่รอ 5 นาที
  const MAINTENANCE_CHECK_INTERVAL_MS = 15 * 1000;
  setInterval(async () => {
    try {
      await checkAndEnforceMaintenanceSchedule();
    } catch (err) {
      console.error("Maintenance countdown cron error:", err.message);
    }
  }, MAINTENANCE_CHECK_INTERVAL_MS);

  // ── เก็บ Snapshot แรกทันทีตอน Server เริ่มทำงาน ไม่ต้องรอ 5 นาทีแรก ──
  takeRamSnapshot().catch(err => console.error("Initial RAM snapshot error:", err.message));
  takeCpuSnapshot().catch(err => console.error("Initial CPU snapshot error:", err.message));
  checkAndSyncPeriodStatus().catch(err => console.error("Initial AP period sync error:", err.message));
  checkAndSyncIEPeriodStatus().catch(err => console.error("Initial IE period sync error:", err.message));
});